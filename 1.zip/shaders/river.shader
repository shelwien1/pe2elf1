#include "common/baseCG.hlsl"
#include "common/PBSLighting.hlsl"
#include "common/standardCore.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"


Texture2D<float4> _mainTexture : register(t0);
TextureCube<float4> _env : register(t1);
Texture2D<float4> _noiseMap : register(t2);
Texture2D<float> _depthBuffer : register(t12);
Texture2D<float4> _foam : register(t3);
SamplerState riverSampler : register(s1);

CBUFFER_START(Data, 0)
    float4 shallowColor;
    float4 deepColor;
    float river_speed;
    float river_tiling;
    float metallic;
    float roughness;
    float riverDeep;

    float foamDistance;
	float foamTiling;
    float foamSpeed;
    float foamStrength;

CBUFFER_END


struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
    float2 uv1 : TEXCOORD1;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float3 position : POSITION0;
    float4 pos : POSITION1;
    float2 uv : TEXCOORD0;
    float2 flow : TEXCOORD1;
    float4 viewSpacePos : TEXCOORD2;
    float4 lightViewPosition[4] : TEXCOORD3;    
    float3 fowUV: TEXCOORD7;
#ifdef _FOG
    float fogFactor : FOG;
#endif
};

float depthFade(float distance, float4 vertexPos)
{
    float3 screenPos = vertexPos.xyz / vertexPos.w; 
    float2 uv = 0.5f * float2(screenPos.x,-screenPos.y) + 0.5f;

    float depth = _depthBuffer.Sample(defaultSampler, uv).r;
    float d1 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - depth * (cameraFarPlane - cameraNearPlane));
    float d2 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - screenPos.z * (cameraFarPlane - cameraNearPlane));

    float d = saturate((d1 - d2) / distance);

    float contrastPower = 2;
    float res = 0.5 * pow(saturate(2 * ((d > 0.5) ? 1 - d : d)), contrastPower);
    res = (d > 0.5) ? 1-res : res;
    return res;
}

float4 calculateFoam(float2 uv, float dstFromShore)
{
    float2 foamMaskOffset = normalize(float2(-0.5, -1)) * foamSpeed * 0.01f * time.x;
    float foamMask = _foam.Sample(defaultSampler, uv * foamTiling + foamMaskOffset).r;
    float2 foamMaskOffset2 = normalize(float2(0.5, -1)) * foamSpeed * 0.01f * time.x;
    float foamMask2 = _foam.Sample(defaultSampler, uv * foamTiling + foamMaskOffset2).r;
    foamMask = foamMask * foamMask2;
    return saturate(1-dstFromShore) * foamMask;
}

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    float4 pos = float4(v.position.xyz, 1);
    o.pixelPosition = mul(pos, matrixViewProj);
    o.pos = o.pixelPosition;
    
    o.position = pos.xyz;
    o.uv = v.uv;
    o.flow = v.uv1;
    o.fowUV.xy = v.position.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.position.z - _heightMap[o.position.xy] * terrainHeight) / 10);
#ifdef _FOG
    float3 cameraPosition = mul(float4(o.position,1), matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));
#endif

    o.viewSpacePos = mul(pos, matrixView);
    o.lightViewPosition[0] = mul(pos, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(pos, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(pos, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(pos, matrix_shadowVP[3]);

    return o;
}

float4 mainPS(v2p p) : SV_TARGET
{
    float speed = river_speed * 0.001 * river_tiling;
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);    

    float height = _heightMap.Sample(defaultSampler, p.position.xy / terrainSize) * terrainHeight;    
    float2 uv = p.uv / terrainSize * river_tiling;// (p.position.xy / terrainSize) * tiling;
    float2 foamUv = p.uv / terrainSize * river_tiling;

	float2 flowmap0 = normalize(float2(0,1));
	float2 flowmap1 = normalize(float2(0,1));

    float phase0 = -time * speed;
    float phase1 = -time * speed + 0.5;

    float2 uv0 = uv + float2(-0.5, 1) * phase0;
    float2 uv1 = uv + float2(0.5f, 0) + float2(0.5, 0.5) * phase1;

    float noise = saturate(_noiseMap.Sample(defaultSampler, uv0).r);    
    float3 normalT0 = unpackNormal(_mainTexture.Sample(riverSampler, uv + uv0).xy);
    float3 normalT1 = unpackNormal(_mainTexture.Sample(riverSampler, uv + uv1).xy);

    float3 n = normalize(float3 (normalT0.xy + normalT1.xy, normalT0.z * normalT1.z));

    float d = depthFade(riverDeep, p.pos);
    float4 color = lerp(shallowColor, deepColor, d);

#ifdef _USE_FOAM
    float4 foam = calculateFoam(p.uv / terrainSize, depthFade(foamDistance, p.pos)) * foamStrength;

    color.rgb = lerp(color.rgb, float3(1,1,1), foam);
    float shoreLine = (1-depthFade(0.1, p.pos));
    color.a = lerp(color.a, 1.0f, foam) * saturate(1-shoreLine);    
#endif    

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, color.rgb, metallic);

    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = 1;

#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif
    color.rgb = pow(abs(color.rgb), 2.2);
    float4 c = BRDF(color.rgb, specColor, roughness, metallic, n, viewDir, gi, shadow);

    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    c.rgb += fow.rgb * p.fowUV.z;

#if defined(_FOG_OF_WAR) && !defined(_DONT_USE_FOW)
    c.rgb = applyFogOwWar(c.rgb, fogColor, fow.a);  
#endif
#ifdef _FOG
    applyHorizontalFog(float4(p.position,1), c.rgb);
#ifndef _DONT_USE_VERTICAL_FOG
    applyVerticalFog(float4(p.position,1), c.rgb);
#endif
    c.rgb = lerp(c.rgb, fogColor, p.fogFactor);
#endif

    return float4(c.rgb, color.a);
}
