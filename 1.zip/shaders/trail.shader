#include "common/baseCG.hlsl"
#include "common/PBSLighting.hlsl"
#include "common/standardCore.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"

Texture2D<float4> albedoTexture : register(t0);
Texture2D<float2> normalTexture : register(t1);
Texture2D<float4> roughTexture : register(t2);
Texture2D<float4> noiseTexture : register(t7);
Texture2D<float4> additionalNoiseTexture : register(t8);

CBUFFER_START(Data, 0)
    float2 randomOffset;
    float trackWidth;
    float trailGapOpacity;
CBUFFER_END

struct VS_INPUT
{
    float4 position : POSITION;
    float3 normal : NORMAL;
    float4 tangent : TANGENT;
    float4 data : TEXCOORD0; //x - alpha
                             //y - index of texture in the sheet
    float4 data2 : TEXCOORD1; //x - alpha
                             //y - index of texture in the sheet
};

struct VS_OUTPUT
{
    float4 position : POSITION;
    float3 normal : NORMAL;
    float4 tangent : TANGENT;
    float4 data : TEXCOORD0;
};

struct GS_OUTPUT
{
    float4 pixelPosition : SV_POSITION;
    float4 position : POSITION;
    float4 data : TEXCOORD0;
    float4 uv1: TEXCOORD1;
    float4 uv2: TEXCOORD2;
    float3 normal : NORMAL;
    float4 tangent : TANGENT;
    float4 viewSpacePos : TEXCOORD3;
    float4 lightViewPosition[4] : TEXCOORD4;
    float3 fowUV: TEXCOORD8;
    float fogFactor : FOG;
};

struct PS_OUTPUT
{
    float4 color : SV_Target;
};

VS_OUTPUT mainVS(VS_INPUT v)
{
    INITIALIZE_OUTPUT(VS_OUTPUT, o);
    o.position = v.position;
    o.normal = v.normal;
    o.tangent = v.tangent;
    o.data = v.data;
    o.data.x *= v.data2.x;
    return o;
}

GS_OUTPUT GetVertex(float4 pos, float3 normal, float4 tangent, float4 uv1, float4 uv2, float4 data) 
{
    INITIALIZE_OUTPUT(GS_OUTPUT, o);

    float bias = 0.08;
    pos += float4(normal * bias, 0);

    o.position = pos;
    o.pixelPosition = mul(pos, matrixViewProj);
    o.uv1 = uv1;
    o.uv2 = uv2;
    o.data = data;
    o.normal = normal;
    o.tangent = tangent;

    o.fowUV.xy = o.position.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.position.z - _heightMap[o.position.xy] * terrainHeight) / 10);

    o.viewSpacePos = mul(o.position, matrixView);
    o.lightViewPosition[0] = mul(o.position, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(o.position, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(o.position, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(o.position, matrix_shadowVP[3]);

    float4 cameraPosition = mul(o.position, matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));

    return o;
}

[maxvertexcount(4)]
void mainGS(lineadj VS_OUTPUT v[4], inout TriangleStream<GS_OUTPUT> triStream)
{
    float4 toStart = v[0].position;
    float4 start = v[1].position;
    float4 end = v[2].position;
    float4 fromEnd = v[3].position;

    //Нужны для того чтобы построить перпендикуляры.
    //Будет работать потому что по условию расстояние между точками ~одинаковое.
    float2 firstHelper = end.xy - toStart.xy;
    float2 secondHelper = fromEnd.xy - start.xy;

    float4 firstPerpendicular = float4(normalize(float2(firstHelper.y, -firstHelper.x)), 0, 0);
    float4 secondPerpendicular = float4(normalize(float2(secondHelper.y, -secondHelper.x)), 0, 0);

    float slotsCount = 8;
    
    float left1 = v[1].data.y / slotsCount;
    float right1 = left1 + 1 / slotsCount;

    float left2 = v[2].data.y / slotsCount;
    float right2 = left2 + 1 / slotsCount;

    triStream.Append(GetVertex(start - firstPerpendicular * trackWidth / 2, v[1].normal, v[1].tangent, float4(left1, v[1].data.z, 0, 0),  float4(left2, v[1].data.z, 0, 0),  v[1].data));
    triStream.Append(GetVertex(start + firstPerpendicular * trackWidth / 2, v[1].normal, v[1].tangent, float4(right1, v[1].data.z, 0, 0), float4(right2, v[1].data.z, 0, 0), v[1].data));
    triStream.Append(GetVertex(end - secondPerpendicular  * trackWidth / 2, v[2].normal, v[2].tangent, float4(left1, v[2].data.z, 1, 0),  float4(left2, v[2].data.z, 1, 0),  v[2].data));
    triStream.Append(GetVertex(end + secondPerpendicular  * trackWidth / 2, v[2].normal, v[2].tangent, float4(right1, v[2].data.z, 1, 0), float4(right2, v[2].data.z, 1, 0), v[2].data));

    triStream.RestartStrip();
}

SurfaceStandard Setup(GS_OUTPUT p)
{
    INITIALIZE_OUTPUT(SurfaceStandard, o);

    //замешиваем альбедо
    float4 albedo1 = albedoTexture.Sample(defaultSampler, p.uv1);
    float4 albedo2 = albedoTexture.Sample(defaultSampler, p.uv2);

    float alpha = p.uv1.z;
    float4 blended = lerp(albedo1, albedo2, alpha);
    
    o.Albedo = blended.rgb;

    const int textureSize = 4; //в метрах
    const int numTiles = terrainSize / textureSize;
    const float smooth = 0.3;
    float dissolve = noiseTexture.Sample(defaultSampler, p.position / terrainSize * numTiles + randomOffset).r;
    
    const int additionalNoiseTextureSize = 4; //так же в метрах
    const float threshold = 0.7;
    float additionalDissolve = additionalNoiseTexture.Sample(defaultSampler, p.position / terrainSize * additionalNoiseTextureSize + randomOffset).r;

    o.Alpha = saturate(blended.a - smoothstep(p.data.x, p.data.x + smooth, dissolve) - smoothstep(threshold, threshold + trailGapOpacity, additionalDissolve));
    
    o.Normal = normalize(p.normal);

#ifdef _NORMAL
    o.Normal = unpackNormal(normalTexture.Sample(defaultSampler, p.uv1));
    float3x3 TBN = makeTBN(p.normal, p.tangent);
    o.Normal = normalize(mul(o.Normal, TBN));    
#endif

#ifdef _ROUGH
    float4 rough = roughTexture.Sample(defaultSampler, p.uv1);
    o.Metallic = rough.r;
    o.Roughness = rough.g;
    o.Occlusion = rough.b; 
#else
    o.Metallic = 0;
    o.Roughness = 1;
    o.Occlusion = 1;
#endif

    return o;
}

PS_OUTPUT mainPS(GS_OUTPUT p)
{
    SurfaceStandard s = Setup(p);

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, s.Albedo, s.Metallic);
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);    
  
    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = s.Occlusion;

#if defined(_SHADOW)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif

    s.Albedo = pow(abs(s.Albedo), 2.2);
    float4 c = BRDF(s.Albedo, specColor, s.Roughness, s.Metallic, s.Normal, viewDir, gi, shadow);
    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    c.rgb += fow.rgb * p.fowUV.z;
    float3 color = c.rgb * exposure.r;

    color = applyFogOwWar(color, fogColor.rgb, fow.a); 

    applyHorizontalFog(p.position, color);
    color = lerp(color, fogColor.rgb, p.fogFactor);

    INITIALIZE_OUTPUT(PS_OUTPUT, o);
    o.color = float4(color, s.Alpha);

    return o;
}