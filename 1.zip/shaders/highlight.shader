#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"

Texture2D<float4> _mainTexture : register(t0);
Texture2D<float> _heightMap : register(t10);

CBUFFER_START(HighlightCB, 0)
    float4 color;
CBUFFER_END

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
	
	float4 worldPos = mul(float4(v.position.xyz, 1), matrix_ObjectToWorld);
	
    o.pixelPosition = mul(worldPos, matrixViewProj);
    o.uv = v.uv;
    o.color = float4(1,1,1,1);
	
    return o;
}

float4 mainPS(v2p p) : SV_TARGET
{
    return color *_mainTexture.Sample(defaultSampler, p.uv);
}
