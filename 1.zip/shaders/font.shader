cbuffer DataPerFrame : register(b1)
{
    float4x4 matrixProj;
    float4x4 matrixView;
    float4x4 matrixInvView;
    float4x4 matrixViewProj;
    float4x4 matrixViewProj2D;
    float3 worldSpaceCameraPos;
}

Texture2D<float4> fontTexture : register(t0);
SamplerState fontSampler : register(s0);

struct FontVertex
{
    float2 position : POSITION;
	float2 uv : TEXCOORD0;
	uint diffuse : COLOR0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
	float2 uv : TEXCOORD0;
	uint diffuse : COLOR0;
};

float4 unpack(uint color)
{
	uint b = ( color & 0x000000FF);
	uint g = ( color & 0x0000FF00) >> 8;
	uint r = ( color & 0x00FF0000) >> 16;
	uint a = ( color & 0xFF000000) >> 24;
	return float4(r, g, b, a) / 255;
}

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(FontVertex v)
{
	v2p o;
    o.pixelPosition = mul(float4(v.position.xy,0,1), matrixViewProj2D);
	o.diffuse = v.diffuse;
	o.uv = v.uv;
    return o;
}

//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
float4 mainPS(v2p p) : SV_TARGET
{
	float4 w0 = fontTexture.Sample(fontSampler, p.uv);
    return w0 * unpack(p.diffuse);
}