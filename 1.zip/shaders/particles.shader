#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"
#include "common/light.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"

Texture2D<float4> _texture : register(t0);
Texture2D<float> _depthBuffer : register(t1);
Texture2D<float> _heightMap : register(t10);
Texture2D<float2> _normalMap : register(t11);

void applyFog(in float4 pos, inout float3 pixel)
{
    pixel = lerp(pixel, fogColor.rgb, saturate((pos.x - fogMax.x) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((fogMin.x - pos.x) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((pos.y - fogMax.y) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((fogMin.y - pos.y) / fogBorder));
}

#define MAX_PARTICLES 2048

struct v2i
{
    float2 uv: TEXCOORD0;
};

struct v2p
{
    float4 position : SV_POSITION;
    float4 worldPosition : POSITION;
    float2 uv : TEXCOORD0;
    float4 diffuse: COLOR;
    float3 normal: NORMAL;
    float4 screenPos : TEXCOORD1;
    float posz: TEXCOORD2;
    float shade_factor: TEXCOORD3;
    float4 lightViewPosition[3] : TEXCOORD4;
    float3 fowUV: TEXCOORD7;
};

struct ParticleData
{
    float4 position;
    float4 velocity;
    float4 ribbon;
    uint color;
    float size;
    float phase;
    float angle;
};

StructuredBuffer<ParticleData> particlesData : register(t2);

CBUFFER_START(Settings, 13)
    float2 frames;
    float shading;
    float emissionPower;
CBUFFER_END



static float2 vertexShift[4] = { float2(-0.5, -0.5), float2(-0.5, 0.5), float2(0.5, 0.5), float2(0.5, -0.5)};
static float2 g_uv[4] = { float2(0, 0), float2(0, 1), float2(1, 1), float2(1, 0)};
static float g_kite[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
static float g_rail[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
static float g_fTrailLengthFactor = 0.3;
static float g_particleSize = 1.0f;


float4 unpackColor(uint color)
{
	uint b = ( color & 0x000000FF);
	uint g = ( color & 0x0000FF00) >> 8;
	uint r = ( color & 0x00FF0000) >> 16;
	uint a = ( color & 0xFF000000) >> 24;
	return float4(r, g, b, a) / 255;
}

float getPhase(uint i)
{
#ifdef _PHASE
    return saturate(particlesData[i].phase);
#else
    return 0.0;
#endif        
}

float getSize(uint i)
{
#ifdef _SIZE
	return particlesData[i].size;
#else
    return 1;
#endif  
}

float4 getColor(uint i)
{
#ifdef _COLOR    
    return unpackColor(particlesData[i].color);
#else
    return float4(1,1,1,1);
#endif        
}

float getAngle(uint i)
{
#ifdef _ANGLE
	return particlesData[i].angle;
#else
    return 0;
#endif        
}

float3 getRigbbon(uint i)
{
#ifdef _RIBBON
	return particlesData[i].ribbon.xyz;
#else
    return 0;
#endif        
}


float3 MakeQuadParticle(float size, float2 uv)
{
    float2 tuv = (uv - float2(0.5,0.5)) * size;
    return float3(tuv, 0);
}

float3 MakeKiteParticle(float size, float2 uv, float3 vel, float kite, float3 viewDir)
{
    float vellen = length(vel);
    float3 camdir = viewDir;//float3(matrixView[0][2], matrixView[1][2], matrixView[2][2]);
    float3 tveldir = vel/vellen;
    float3 tperpdir = normalize(cross(camdir,tveldir));
    float3 veldir = (tveldir + tperpdir)*0.5f;
    float3 perpdir = (tveldir - tperpdir)*0.5f;
    float2 tuv = (uv - float2(0.5f,0.5f)) * size;
    float3 shift = tuv.x * veldir + tuv.y * perpdir;
    return shift + normalize(shift) * (kite * vellen * g_fTrailLengthFactor);
}

float3 MakeRailParticle(float size, float2 uv, float3 vel, float rail, float3 viewDir)
{
    float3 camdir = viewDir;
    float3 veldir = normalize(vel);
    float3 perpdir = normalize(cross(camdir,veldir));
    float2 tuv = (uv - float2(0.5f,0.5f)) * size;
    return (tuv.x + rail * g_fTrailLengthFactor) * veldir + tuv.y * perpdir;
}

float2 LocateTextureFrame(float2 uv, float phase, float sizeX, float sizeY)
{
    float szXinv = 1.f/sizeX;
    float szYinv = 1.f/sizeY;

    return float2(uv.x * szXinv + floor(fmod(phase * sizeX * sizeY, sizeX)) * szXinv, uv.y * szYinv + floor(phase * sizeY) * szYinv);
}

float3 MakeRibbonParticle(float size, float2 uv, float3 ribbon, float4x4 worldview)
{
    float3 shift = mul(ribbon, (float3x3)worldview);
    return normalize(float3(shift.y,-shift.x,0.0f)) * (uv.x - 0.5f) * size;
}


v2p setup(v2i v, uint id)
{
    INITIALIZE_OUTPUT(v2p, o);

    float phase = getPhase(id);

#ifdef _PHASE
    o.uv = LocateTextureFrame(v.uv, phase, frames.x, frames.y);
#else
    o.uv = v.uv;
#endif

    o.diffuse = getColor(id);
    o.position = particlesData[id].position;
    return o;
}

float3 shade(float3 shift, float size)
{
    float2 n = normalize(shift.xy/size);

    float3 l3d = mul(directLightDir, (float3x3)matrixView);
    float2 l = normalize(float2(l3d.x, abs(l3d.y) - l3d.z));
    float nl = 1.0f-max(0, dot(n,l));
    return lerp(1.0, nl, shading);
    //return diffuse * nl;
}

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(v2i v, uint id : SV_InstanceID)
{
    v2p o = setup(v, id);
    float size = getSize(id);
    float3 shift = MakeQuadParticle(size, v.uv);


#ifdef _ANGLE    
    float sina, cosa;
    sincos(getAngle(id), sina, cosa);
    shift = float3(shift.x * cosa + shift.y * sina, shift.y * cosa - shift.x * sina, 0.0);
#endif    

#ifdef _SHADED
    o.diffuse.rgb *= shade(shift, size);
#endif
    
    o.position = mul(o.position, matrixView) + float4(shift.x, -shift.y, shift.z, 0);
    o.worldPosition = mul(o.position, matrixInvView);
    o.normal = normalize(worldSpaceCameraPos - o.worldPosition.xyz);
    o.position = mul(o.position, matrixProj);

    o.fowUV.xy = o.worldPosition.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.worldPosition.z - _heightMap[o.worldPosition.xy]*terrainHeight)/10);



    //o.position = o.position + mul(float4(shift.x, -shift.y, shift.z, 0), matrixInvView);
    //o.position = mul(o.position, matrixViewProj);
    o.screenPos.xy = o.position.xy / o.position.w;
    o.posz = o.position.z / o.position.w;

    return o;
}


v2p kiteVS(v2i v, uint idx: SV_VertexID, uint id : SV_InstanceID)
{
    v2p o = setup(v, id);
    uint vertex_index = idx % 4;

    float3 viewDir = WorldSpaceViewDir(o.position.xyz);
    float size = getSize(id);
    float3 shift = MakeKiteParticle(size, v.uv, particlesData[id].velocity.xyz, g_kite[vertex_index], viewDir);

#ifdef _SHADED
    o.diffuse.rgb *= shade(shift, size);
    //o.shade_factor = shade(shift, size);
#endif

    o.position = o.position + float4(shift, 0);
    o.worldPosition = o.position;
    o.normal = normalize(worldSpaceCameraPos - o.worldPosition.xyz);
    o.position = mul(o.position, matrixViewProj);

    o.fowUV.xy = o.worldPosition.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.worldPosition.z - _heightMap[o.worldPosition.xy]*terrainHeight)/10);

    o.screenPos.xy = o.position.xy / o.position.w;
    o.posz = o.position.z / o.position.w;

    return o;
}

v2p railVS(v2i v, uint idx: SV_VertexID, uint id : SV_InstanceID)
{
    v2p o = setup(v, id);
    uint vertex_index = idx % 4;

    float3 viewDir = WorldSpaceViewDir(o.position.xyz);
    float size = getSize(id);
    float3 shift = MakeRailParticle(size, v.uv, particlesData[id].velocity.xyz, g_rail[vertex_index], viewDir);

#ifdef _SHADED
    o.shade_factor = shade(shift, size);
#endif

    o.position = o.position + float4(shift, 0);
    o.worldPosition = o.position;
    o.normal = normalize(worldSpaceCameraPos - o.worldPosition.xyz);
    o.position = mul(o.position, matrixViewProj);

    o.fowUV.xy = o.worldPosition.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.worldPosition.z - _heightMap[o.worldPosition.xy]*terrainHeight)/10);

    o.screenPos.xy = o.position.xy / o.position.w;
    o.posz = o.position.z / o.position.w;
    return o;
}

v2p ribbonVS(v2i v, uint id : SV_InstanceID)
{
    v2p o = setup(v, id);
    float size = getSize(id);
    float3 shift = mul(particlesData[id].ribbon.xyz, (float3x3)matrixView);
    shift = float3(normalize(float2(-shift.y, shift.x)) * (v.uv.x - 0.5f),0) * size;

    o.position -= particlesData[id].ribbon * v.uv.y;
    o.position = mul(o.position, matrixView) + float4(shift,0);
    o.worldPosition = mul(o.position, matrixInvView);
    o.normal = normalize(worldSpaceCameraPos - o.worldPosition.xyz);
    o.position = mul(o.position, matrixProj);
    
    o.fowUV.xy = o.worldPosition.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.worldPosition.z - _heightMap[o.worldPosition.xy]*terrainHeight)/10);

    
    o.screenPos.xy = o.position.xy / o.position.w;
    o.posz = o.position.z / o.position.w;

    return o;    
}

//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
#ifdef SHADOW_DEPTH 
void mainPS(v2p p) 
{
}
#else
struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 emission: SV_Target1;
};
PS_OUTPUT mainPS(v2p p) : SV_TARGET
{
    INITIALIZE_OUTPUT(PS_OUTPUT, o)
    o.color = _texture.Sample(defaultSampler, p.uv);
    o.emission = o.color;

    o.color.rgb *= ambientColor.rgb + addFactor;
    o.color.rgb *= p.diffuse.rgb;
    o.color.a *= p.diffuse.a;

    o.emission.rgb += addFactor;
    o.emission.rgb *= p.diffuse.rgb;
#ifdef _SOFT_PARTICLES

    float2 TexCoord = 0.5f * float2(p.screenPos.x,-p.screenPos.y) + 0.5f;
    float scale     = 50;
    float r = p.position.w;
    
    float zs = _depthBuffer.Sample(defaultSampler, TexCoord).r;
    float d1 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - zs * (cameraFarPlane - cameraNearPlane));
    float d2 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - p.posz * (cameraFarPlane - cameraNearPlane));
    float dz  = min (1, scale * ( d1 - d2 ) / r );

    //color.rgb = dz;
    o.color.a *= saturate(dz);

#endif
    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    o.color.rgb += fow.rgb * p.fowUV.z;
    o.emission.rgb += fow.rgb * p.fowUV.z;

#ifdef _FOG_OF_WAR
    o.color.rgb = applyFogOwWar(o.color.rgb, fogColor.rgb, fow.a);
    o.emission.rgb =  applyFogOwWar(o.emission.rgb, fogColor.rgb, fow.a);
#endif
    //color = float4(1,1,1,1);
#ifdef _FOG
    applyFog(p.worldPosition, o.color.rgb);
    applyFog(p.worldPosition, o.emission.rgb);
#endif
    //color.rgb *= p.shade_factor;
    o.emission.a = o.color.a;
    o.emission *= emissionPower;
    return o;
}
#endif

