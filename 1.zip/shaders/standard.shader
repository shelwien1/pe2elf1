#include "common/baseCG.hlsl"
#include "common/PBSLighting.hlsl"
#include "common/standardCore.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
    float4 viewSpacePos : TEXCOORD1;
    float4 lightViewPosition[4] : TEXCOORD2;
    float4 tangent : TANGENT;
    float3 normal : NORMAL;
    float clip: SV_ClipDistance0;
    float3 fowUV: TEXCOORD6;
#ifdef _USE_VERTEX_COLOR
    float4 colors : COLOR0;
#endif
#ifdef _CAST_SILHOUETTE
    float4 silhouetteColor : COLOR1;
#endif
#ifdef _FOG
    float fogFactor : FOG;
#endif
};


struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 emission: SV_Target1;
	
#if defined(_CAST_SILHOUETTE) || defined(_RECEIVE_SILHOUETTE)
    float4 silhouette:  SV_Target2;	
#endif
};

CBUFFER_START(Data, 0)
    float4 albedoColor;    
    float4 emissionColor;
    float alpha;
    float emissionPower;
    float metallic;
    float roughness;
    float occlusion;
    float2 uvOffset;
    float dummy;    
CBUFFER_END

struct InstatnceObjectBuffer
{
    float4x4 ObjectToWorld;
    float4x4 WorldToObject;
};

StructuredBuffer<InstatnceObjectBuffer> instanceBuffer : register(t33);
float _cutoff = 0.5f;


#ifdef _BROKEN_MESH
CBUFFER_START(BrokenPieceMatrices, 6)
    float4x4 pieceMatrices[1024];    
CBUFFER_END
#endif

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(appdata_base v, uint id : SV_InstanceID)
{
    INITIALIZE_OUTPUT(v2p, o);
#ifdef _CAST_SILHOUETTE
    o.silhouetteColor = silhouetteColor;
//    o.silhouetteColor = float4(0, 1, 0, 1);
#endif
#ifdef _SKINNING
    uint4 blendIndex = (uint4)v.blendIndices; 

    float4x4 blendMatrix = 
        skinMatrix[blendIndex.x] * v.blendWeighs.x + 
        skinMatrix[blendIndex.y] * v.blendWeighs.y + 
        skinMatrix[blendIndex.z] * v.blendWeighs.z + 
        skinMatrix[blendIndex.w] * v.blendWeighs.w;

    blendMatrix = mul(matrix_ObjectToWorld, blendMatrix);
    //blendMatrix = mul(blendMatrix, matrix_ObjectToWorld);
    //o.position = mul(float4(v.position.xyz, 1), matrix_ObjectToWorld);
    o.position = mul(float4(v.position.xyz, 1), blendMatrix);
    o.normal = normalize(mul(v.normal.xyz, (float3x3) blendMatrix));
    o.tangent.xyz = normalize(mul(v.tangent.xyz, (float3x3) blendMatrix));
    o.tangent.w = v.tangent.w;

#else
    float4x4 ObjectToWorld;
    float4x4 WorldToObject;    
#ifdef _INSTANSING
    ObjectToWorld = instanceBuffer[id].ObjectToWorld;
    WorldToObject = instanceBuffer[id].WorldToObject;    
#else
    ObjectToWorld =  matrix_ObjectToWorld;
    WorldToObject = matrix_WorldToObject;    
#endif

#ifdef _BROKEN_MESH
    ObjectToWorld = mul(pieceMatrices[(uint)v.uv1.x], ObjectToWorld);
#endif //_BROKEN_MESH

    o.position = mul(float4(v.position.xyz, 1), ObjectToWorld);
    o.normal = normalize(mul(v.normal.xyz, (float3x3) ObjectToWorld));
    o.tangent.xyz = normalize(mul(v.tangent.xyz, (float3x3) ObjectToWorld));
    o.tangent.w = v.tangent.w;
    //o.normal = ObjectToWorldNormal(v.normal.xyz);
    //o.tangent = ObjectToWorldNormal(v.tangent.xyz);
#endif

#ifdef _USE_VERTEX_COLOR
    o.colors =  v.colors; 
#endif

#ifdef _USE_CLIPPING
    o.clip = dot(o.position, clipPlane);
#endif
    o.pixelPosition = mul(o.position, matrixViewProj);    
    //o.pixelPosition = mul(o.pixelPosition, matrixProj);
    //o.uv = float2(v.uv.x, 1.0f - v.uv.y);
    o.uv = v.uv + uvOffset;
    o.fowUV.xy = o.position.xy / terrainSize;
    o.fowUV.z = saturate(1-(o.position.z - _heightMap[o.position.xy]*terrainHeight)/10);

    o.viewSpacePos = mul(o.position, matrixView);
    o.lightViewPosition[0] = mul(o.position, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(o.position, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(o.position, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(o.position, matrix_shadowVP[3]);
#ifdef _FOG
    float4 cameraPosition = mul(o.position, matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));
#endif

    return o;
}

SurfaceStandard Setup(v2p p)
{
    INITIALIZE_OUTPUT(SurfaceStandard, o);

    o.Alpha = alpha;
#ifdef _ALBEDO
    half4 albedo = (half4)_albedoTexture.Sample(defaultSampler, p.uv);
    o.Albedo = albedo.rgb;
    o.Alpha = o.Alpha * albedo.a;

    o.Alpha = o.Alpha * albedoColor.a;
    o.Albedo = o.Albedo * albedoColor.rgb;
    
#ifdef _USE_VERTEX_COLOR
    o.Albedo = o.Albedo * p.colors.rgb;
    o.Alpha = o.Alpha * p.colors.a;
#endif
#else
    o.Albedo = albedoColor.rgb;
#endif

    o.Normal = normalize(p.normal);

#ifdef _NORMAL
    o.Normal = unpackNormal(_normalTexture.Sample(defaultSampler, p.uv));
    float3x3 TBN = makeTBN(p.normal, p.tangent);
    o.Normal = normalize(mul(o.Normal, TBN));    
#endif
#ifdef _ROUGH
    half4 rough = (half4)_roughTexture.Sample(defaultSampler, p.uv);
    o.Metallic = rough.r;
    o.Roughness = rough.g;
    o.Occlusion = rough.b;
#else
    o.Metallic = metallic;
    o.Roughness = roughness;
    o.Occlusion = occlusion;
#endif
#ifdef _EMISSION
    o.Emission = _emissionTexture.Sample(defaultSampler, p.uv);
#else
    o.Emission = emissionColor;
#endif
    return o;
}

//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
PS_OUTPUT mainPS(v2p p, bool isFrontFace: SV_IsFrontFace)
{
#ifdef _FLIP_BACKFACE_NORMAL
    p.normal *= (1 - isFrontFace * 2);
#endif    
    SurfaceStandard s = Setup(p);

#ifdef _ALPHA_TEST
    if(s.Alpha < 0.5f)
    {
        discard;
    }
#endif
//#ifdef _FOG
//    if(p.position.x > (fogMax.x + fogBorder) || p.position.y > (fogMax.y + fogBorder) || p.position.x < (fogMin.x - fogBorder) || p.position.y < (fogMin.y - fogBorder))
//        discard;
//#endif    
    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, s.Albedo, s.Metallic);
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);    
  
    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = s.Occlusion;

#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif
    s.Albedo = pow(abs(s.Albedo), 2.2);
    float4 c = BRDF(s.Albedo, specColor, s.Roughness, s.Metallic, s.Normal, viewDir, gi, shadow);
    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    c.rgb += fow.rgb * p.fowUV.z;
    float3 color = c.rgb * exposure.r;    
#if defined(_FOG_OF_WAR) && !defined(_DONT_USE_FOW)
    color = applyFogOwWar(color, fogColor.rgb, fow.a);  
#endif
#ifdef _FOG
    applyHorizontalFog(p.position, color);
#ifndef _DONT_USE_VERTICAL_FOG
    applyVerticalFog(p.position, color);
#endif
#ifdef _DONT_USE_HORIZONTAL_FOG
    p.fogFactor = 0.0;
#endif
    color = lerp(color, fogColor.rgb, p.fogFactor);
#endif
    
INITIALIZE_OUTPUT(PS_OUTPUT, result)
result.color = float4(color + s.Emission.rgb * min(emissionPower, 1) * s.Emission.a, s.Alpha);
//result.color = float4(color, s.Alpha);
result.emission = float4(s.Emission.rgb * emissionPower, s.Emission.a);

#ifdef _CAST_SILHOUETTE   

    float3 a = p.silhouetteColor.rgb;
    float3 b = s.Albedo.rgb + 0.3f;   
    float luminance = dot(b, float3(0.2126, 0.7152, 0.0722));
    //overlay
    result.silhouette.rgb = luminance <= 0.5f ? 2 * a * b : 1 - 2 * (1- a) * (1 - b);    

#endif
#ifdef _RECEIVE_SILHOUETTE
    result.silhouette.a = 1;
#endif
    return result;
}
//--------------------------------------------------------------------------------------
// Shadow Map
//--------------------------------------------------------------------------------------
struct VS_OUTPUT_SHADOWMAP_INSTANCING
{
  float4 position : POSITION;
  uint iSplit : TEXTURE0;
  float2 uv: TEXCOORD1;
};

struct GS_OUTPUT_SHADOWMAP
{
  float4 vPos : SV_POSITION;
  float2 uv: TEXCOORD0;
  uint RTIndex : SV_RenderTargetArrayIndex;
};

VS_OUTPUT_SHADOWMAP_INSTANCING shadowVS(appdata_base v, uint id : SV_InstanceID)
{
    INITIALIZE_OUTPUT(VS_OUTPUT_SHADOWMAP_INSTANCING, o);
#ifdef _SKINNING
    uint4 blendIndex = (uint4)v.blendIndices; 

    float4x4 blendMatrix = 
        skinMatrix[blendIndex.x] * v.blendWeighs.x + 
        skinMatrix[blendIndex.y] * v.blendWeighs.y + 
        skinMatrix[blendIndex.z] * v.blendWeighs.z + 
        skinMatrix[blendIndex.w] * v.blendWeighs.w;

    blendMatrix = mul(matrix_ObjectToWorld, blendMatrix);
    o.position = mul(float4(v.position.xyz, 1), blendMatrix);
#elif defined(_BROKEN_MESH)
    o.position = mul(float4(v.position.xyz, 1), mul(pieceMatrices[(uint)v.uv1.x], matrix_ObjectToWorld));
#else //_BROKEN_MESH
    o.position = mul(float4(v.position.xyz, 1), matrix_ObjectToWorld);
#endif
    o.iSplit = firstSplitIndex + id;
    o.position = mul(o.position, matrixViewProj);
    o.position = mul(o.position, matrix_shadowVP[o.iSplit]);
    o.uv = v.uv;
    return o;
}

[maxvertexcount(3)]
void shadowGS( triangle VS_OUTPUT_SHADOWMAP_INSTANCING In[3], inout TriangleStream<GS_OUTPUT_SHADOWMAP> TriStream )
{
    GS_OUTPUT_SHADOWMAP Out;
    // set render target index
    Out.RTIndex = In[0].iSplit;
    // pass vertices through
    Out.vPos = In[0].position;
    Out.uv = In[0].uv;
    TriStream.Append(Out);
    Out.vPos = In[1].position;
    Out.uv = In[1].uv;
    TriStream.Append(Out);
    Out.vPos = In[2].position;
    Out.uv = In[2].uv;
    TriStream.Append(Out);
    TriStream.RestartStrip();
}

void shadowPS(GS_OUTPUT_SHADOWMAP i)
{
#ifdef _ALBEDO
    half4 albedo = (half4)_albedoTexture.Sample(defaultSampler, i.uv);
     if(albedo.a < 0.5f)
         discard;
#endif
}

float3 overlay (float3 base, float3 blend)
{
	float3 isLessOrEq = step(base, 0.5f);
	return lerp(2 * blend * base, 1 - (1 - 2 * (base - 0.5f)) * (1 - blend), isLessOrEq);
}

float3 hardLight (float3 base, float3 blend)
{
	float3 isLessOrEq = step(blend, .5);
	return lerp(1.0f - (1.0f - base) * (1.0f - 2.0f * (blend - 0.5)), 2.0 * blend * base, isLessOrEq);
}

PS_OUTPUT damagePS(v2p p, bool isFrontFace: SV_IsFrontFace)
{
    ///

    INITIALIZE_OUTPUT(PS_OUTPUT, result)
    SurfaceStandard s = Setup(p);

    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = s.Occlusion;

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, s.Albedo, s.Metallic);
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);
    
#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif

    s.Albedo = pow(abs(s.Albedo), 2.2);

    float4 c = BRDF(s.Albedo, specColor, s.Roughness, s.Metallic, s.Normal, viewDir, gi, shadow);
    float3 color = c.rgb * exposure.r;

    result.color = float4(color + s.Emission.rgb * min(emissionPower, 1) * s.Emission.a, s.Alpha);
    result.color.rgb = lerp(result.color.rgb, hardLight(result.color.rgb, damageColor.rgb), lerp(damageColorAlpha.x, damageColorAlpha.y, (sin(time * PI * damageColorPulseFrequency) + 1.0f) / 2.0f));
    result.emission = float4(s.Emission.rgb * emissionPower, s.Emission.a);
    return result;
}

PS_OUTPUT logicBoxDamagePS(v2p p, bool isFrontFace: SV_IsFrontFace)
{
    ///

    INITIALIZE_OUTPUT(PS_OUTPUT, result)
    SurfaceStandard s = Setup(p);

    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = s.Occlusion;

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, s.Albedo, s.Metallic);
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);
    
#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif
    s.Albedo = pow(abs(s.Albedo), 2.2);

    float4 c = BRDF(s.Albedo, specColor, s.Roughness, s.Metallic, s.Normal, viewDir, gi, shadow);
    float3 color = c.rgb * exposure.r;

    result.color = float4(color + s.Emission.rgb * min(emissionPower, 1) * s.Emission.a, s.Alpha);
    
    result.emission = float4(s.Emission.rgb * emissionPower, s.Emission.a);

    ///

    float3 a;
    float3 b = result.color.rgb;
    for(int i = 0; i < count; i++)
    {
        DamageOBB obb = obbs[i];

        float3 actualPosition = p.position.xyz - obb.pos.xyz;

        float axisXLength = length(obb.sizeX);
        float dotX = dot(actualPosition, obb.sizeX.xyz / axisXLength);
        if(abs(dotX) > axisXLength) continue;

        float axisYLength = length(obb.sizeY);
        float dotY = dot(actualPosition, obb.sizeY.xyz / axisYLength);
        if(abs(dotY) > axisYLength) continue;

        float axisZLength = length(obb.sizeZ);
        float dotZ = dot(actualPosition, obb.sizeZ.xyz / axisZLength);
        if(abs(dotZ) > axisZLength) continue;

        a = obb.color.rgb;

        result.color.rgb = lerp(result.color.rgb, hardLight(result.color.rgb, obb.color.rgb), lerp(obb.colorAlpha.x, obb.colorAlpha.y, (sin(time * PI * damageColorPulseFrequency) + 1.0f) / 2.0f));
        break;
    }
        

    return result;
}

PS_OUTPUT dead(v2p p, bool isFrontFace: SV_IsFrontFace)
{
    INITIALIZE_OUTPUT(PS_OUTPUT, result)
    result.color = float4(albedoColor.rgb, 1);
    result.emission = float4(0,0,0,0);
    return result;
}