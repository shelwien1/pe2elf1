#include "common/baseCG.hlsl"


struct v2p
{
    float4 position : SV_POSITION;
};

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(appdata_base v)
{
    INITIALIZE_OUTPUT(v2p, o);
    //float4 position = mul(v.position, matrix_ObjectToWorld);
    o.position = mul(mul(float4(v.position.xyz, 1.0), matrix_ObjectToWorld), matrixViewProj);
    return o;
}
//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
float4 mainPS(v2p p) : SV_TARGET
{
    return 1;
}

