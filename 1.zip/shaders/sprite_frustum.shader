#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"

#define M_PI (3.1415926535897932384626433832795)
Texture2D<float4> _mainTexture : register(t0);

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.pixelPosition = mul(v.position, matrixViewProj);
    o.uv = v.uv;
    o.color = v.color;
    
    return o;
}

float4 mainPS(v2p p) : SV_TARGET
{
    float4 color = _mainTexture.Sample(defaultSampler, p.uv);
    return color;
}
float4 borderPS(v2p p) : SV_TARGET
{
    return float4(p.color.rgb,sin(saturate(p.uv.x) * M_PI) * p.color.a );
}