#include "common/baseCG.hlsl"

SamplerState frameSampler : register(s1);

Texture2D<float4> _fill : register(t0);
Texture2D<float4> _image : register(t1);
Texture2D<float4> _alpha : register(t2);

CBUFFER_START(Data, 0)
    float4 colorBorder;

	float outlineThickness;
	float minAlpha;
	float maxAlpha;
	float tiling;

    float innerRadius;
	float outerRadius;
    float scaleX;
    float scaleY;

    float sina;
    float cosa;

CBUFFER_END

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
    float2 uv1 : TEXCOORD1;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
    float2 uv1 : TEXCOORD1;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.position = mul(float4(v.position.xyz, 1), matrix_ObjectToWorld); 
    o.pixelPosition = mul(o.position, matrixViewProj);
    o.uv = v.uv;
    o.uv1 = v.uv1;
    return o;
}

float3 gammaConvertation(float3 color)
{
    return pow(abs(color), 2.2);
}

float antialias(v2p p, float outRadius, float inRadius)
{
    float len = length(p.uv);
    float fw = fwidth(len);
    float outStep = smoothstep(outRadius + fw, outRadius - fw, len);
    float inStep = smoothstep(inRadius + fw, inRadius - fw, len);
    return outStep - inStep;
}

float4 gridPS(v2p p) : SV_TARGET
{   
    //discard; 

    float2 uvOffset = p.position.xy / float2(scaleX, scaleY);
    float4 result = _fill.Sample(defaultSampler, uvOffset);
    float4 alpha = _alpha.Sample(defaultSampler, p.uv);
    result.a = saturate(result.a  * alpha.r);
    result.rgb =  gammaConvertation(result.rgb);
    return result;
  //return float4(1.f, 1.f, 1.f, 1.f);
}


float4 missilePS(v2p p) : SV_TARGET
{       
    //discard; 

    float2x2 rotationMatrix = float2x2(cosa, sina, -sina, cosa);
    float2 cacheUV = p.uv;
    cacheUV -= float2(0.5, 0.5);
    cacheUV = mul(rotationMatrix, cacheUV) + float2(0.5, 0.5);
    
    float4 result = _fill.Sample(defaultSampler, p.uv);
#ifdef USE_IMAGE
    float4 targetCache = _image.Sample(frameSampler, cacheUV);
    if(targetCache.a != 0.f)
    {
       result = targetCache;
    }
#endif
    result.rgb =  gammaConvertation(result.rgb);
    return result;
  //return float4(1.f, 1.f, 1.f, 1.f);
}

float4 rushPS(v2p p) : SV_TARGET
{       
     //discard; 
    float innerRad = innerRadius / 2.0;
    float outerRad = outerRadius / 2.0;

    float sqrUVOuterRadius = outerRad * outerRad;
    float uvLenght = dot(p.uv, p.uv);
    if(uvLenght > sqrUVOuterRadius)
        discard;
        
    float4 result = _fill.Sample(defaultSampler, p.uv * tiling) * antialias(p, outerRad - outlineThickness, 0);
    result.a = saturate(result.a * (minAlpha + uvLenght/sqrUVOuterRadius * maxAlpha));
    
    if(sqrUVOuterRadius - outlineThickness < uvLenght)
    {
        result =+ colorBorder * antialias(p, outerRad - outlineThickness, outerRad);
    }

    if(abs(p.uv.x) < innerRad  && abs(p.uv.y) < innerRad)
    {
        float4 imageColor = _image.Sample(defaultSampler, p.uv1);         
        if(imageColor.a > 0)
        {
            result =+ imageColor * antialias(p, innerRad, 0);
        }
    }

    result.rgb =  gammaConvertation(result.rgb);
     //return float4(p.uv, 0.f, 1.f);
    return result;
}

float4 mainPS(v2p p) : SV_TARGET
{
    //discard; 
    float2x2 rotationMatrix = float2x2(cosa, sina, -sina, cosa);

    float2 cacheUV = p.uv;
    cacheUV -= float2(0.5, 0.5);
    cacheUV = mul(rotationMatrix, cacheUV) + float2(0.5, 0.5);

    float4 result = _fill.Sample(frameSampler, cacheUV);
    result.rgb =  gammaConvertation(result.rgb);
    return result;
}