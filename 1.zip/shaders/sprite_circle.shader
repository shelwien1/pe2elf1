#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"

CBUFFER_START(Data, 0)
    float4x4 worldMatrix;
    
    float4 innerColor;
    float4 outerColor;

    float4 innerOutlineColor;
    float4 outerOutlineColor;

    float innerRadius;
    float outlineThickness;

    float minAlpha;
    float maxAlpha;
CBUFFER_END

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);

    o.pixelPosition = mul(mul(v.position, worldMatrix), matrixViewProj);
    o.uv = v.uv;

    return o;
}

float antialias(v2p p, float outRadius, float inRadius)
{
    float len = length(p.uv);
    float fw = fwidth(len);
    float outStep = smoothstep(outRadius + fw, outRadius - fw, len);
    float inStep = smoothstep(inRadius + fw, inRadius - fw, len);
    return outStep - inStep;
}

float4 mainPS(v2p p) : SV_TARGET
{
    float outBound = 1 - outlineThickness;
    float sqrOutlineBound = outBound * outBound;

    float sqrInnerRadius = innerRadius * innerRadius;

    float sqrLength = dot(p.uv, p.uv);
    
    if(sqrLength > 1)
        discard;

    float4 result = float4(0, 0, 0, 0);
    
    //внешнее кольцо
    result += float4(outerOutlineColor.rgb, 1) * antialias(p, 0.99, outBound);

    //внешний градиент
    float outerSqrRadius = 1 - sqrInnerRadius;
    float outerSqrLength = sqrLength - sqrInnerRadius / outerSqrRadius;
    result += float4(outerColor.rgb, saturate(minAlpha + outerSqrLength * maxAlpha)) * antialias(p, outBound, innerRadius);

    //внутреннее кольцо
    float innerOutline = innerRadius - outlineThickness;
    float sqrInnerOutline = innerOutline * innerOutline;
    result += float4(innerOutlineColor.rgb, 1) * antialias(p, innerRadius, innerOutline);

    //внутренний градиент
    float innerSqrLength = sqrLength / sqrInnerRadius;
    result += float4(innerColor.rgb, saturate(minAlpha + innerSqrLength * maxAlpha)) * antialias(p, innerOutline, 0);

    return result;
}
