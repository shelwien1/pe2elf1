#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"
#include "common/standardCore.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/fow.hlsl"

 //Texture2D<float4> _mainTexture : register(t0);
//Texture2D<float4> _normalTexture : register(t1);
Texture2D<float4> _terrainTexture : register(t3);
Texture2D<float4> _windMap : register(t20);
SamplerState grassSampler : register(s1);
SamplerState windSampler : register(s2);
struct VS_INPUT
{
    float4 position : POSITION;
    float3 normal : NORMAL;
    float2 size : TEXCOORD0;
    float2 data: TEXCOORD1; 
};

struct VS_OUTPUT
{
    float4 position : POSITION;
    float3 normal : NORMAL;
    float2 size : TEXCOORD0;
    uint typeId: TEXCOORD1;
};

struct GS_OUTPUT
{
    float4 pixelPosition : SV_POSITION;
    float4 position : POSITION;
    float4 uv: TEXCOORD0;
    float3 normal : NORMAL;
    float4 tangent : TANGENT;
    float4 viewSpacePos : TEXCOORD1;
    float4 lightViewPosition[4] : TEXCOORD2;
    float2 fowUV: TEXCOORD7;
#ifdef _FOG
    float fogFactor : FOG;
#endif    
};

struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 emission: SV_Target1;
};

static const int BushType = 0;
static const int WheatType = 1;

struct BushData {
    float4 rect;
    int type;
    float windMultiplier;
    float2 padding;
};

CBUFFER_START(Data, 0)
    BushData bushData[32];

    float mapSize;
    float windMapScale;
    float windSpeed;
    float grassAmplitude;
    float grassDistance;
CBUFFER_END

VS_OUTPUT mainVS(VS_INPUT v)
{
    INITIALIZE_OUTPUT(VS_OUTPUT, o);
    //o.position = mul(mul(float4(v.position.xyz,1), matrix_ObjectToWorld), matrixViewProj);
    o.position = v.position;//mul(float4(v.position.xyz,1), matrixViewProj);
    o.normal = v.normal;
    //o.position.z += _heightMap.SampleLevel(defaultSampler, float2(o.position.x / 256, o.position.y / 256), 0) * terrainHeight;    
    o.size = v.size;
    o.typeId = (uint)v.data.x;
    return o;
}

float random (float2 st) {
    return frac(sin(dot(st.xy,
                        float2(12.9898,78.233)))*
        43758.5453123);
}

GS_OUTPUT GetVertex(float3 pos, float4 uv, float3 normal, float4 tangent) 
{
    INITIALIZE_OUTPUT(GS_OUTPUT, o);
    float4 p = float4(pos, 1);

    o.pixelPosition = mul(p, matrixViewProj);
    o.position = p;
    o.uv = uv;
    o.tangent = tangent;
    o.normal = normal;
    o.viewSpacePos = mul(p, matrixView);
    o.lightViewPosition[0] = mul(p, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(p, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(p, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(p, matrix_shadowVP[3]);    //o.col = col;
    o.fowUV = float2(p.x, p.y) / float2(terrainSize, terrainSize);
#ifdef _FOG
    float3 cameraPosition = mul(o.position, matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));
#endif    
    return o;
}

void addBlade(float3 a, float3 b, float3 center, uint typeId, float3 up, float3 normal, float4 tangent, inout TriangleStream<GS_OUTPUT> triStream)
{
        float3 c = a + up;
        float3 d = b + up;

        float4 uvRect =  bushData[typeId].rect;

        float t = frac(time * windSpeed);

        float2 offset = _windMap.SampleLevel(windSampler, float2(c.x / (512 / windMapScale)  + t, c.y / (512 / windMapScale) + t), 0).xy;
        offset = (offset * 2 - 1) * grassAmplitude * bushData[typeId].windMultiplier;
        c += float3(offset,0);
        offset = _windMap.SampleLevel(windSampler, float2(d.x / (512 / windMapScale) + t, d.y / (512 / windMapScale) - t), 0).xy;
        offset = (offset * 2 - 1) * grassAmplitude * bushData[typeId].windMultiplier;
        d += float3(offset,0);

        float2 uv1 = uvRect.xy;
        float2 uv2 = uvRect.zw;

        triStream.Append(GetVertex(a, float4(uv1.x, uv2.y, 0.0, 0), normal, tangent));
        triStream.Append(GetVertex(b, float4(uv2.x, uv2.y, 0.0, 0), normal, tangent));
        triStream.Append(GetVertex(d, float4(uv2.x, uv1.y, 0.8, 0), normal, tangent));
        triStream.Append(GetVertex(d, float4(uv2.x, uv1.y, 0.8, 0), normal, tangent));
        triStream.Append(GetVertex(a, float4(uv1.x, uv2.y, 0.0, 0), normal, tangent));
        triStream.Append(GetVertex(c, float4(uv1.x, uv1.y, 0.8, 0), normal, tangent));
        triStream.RestartStrip();
}

void bush(float3 midpoint, uint typeId, float2 size, float3 normal, float4 tangent, inout TriangleStream<GS_OUTPUT> triStream)
{
    float angle = 1.0472;
    float3 v0 = normalize(float3(cos(0), sin(0), 0));
    float3 v1 = normalize(float3(cos(angle), sin(angle), 0));
    float3 v2 = normalize(float3(-cos(angle), sin(angle), 0));
    float width = size.x;
    float height = size.y;
    float3 up1 = normalize(float3(0,0.5f,0.866025388f)) * height;
    float3 up2 = normalize(float3(0.433,-0.25,0.866025388f)) * height;
    float3 up3 = normalize(float3(-0.433,-0.25,0.866025388f)) * height;
    float3 a = midpoint - width * 0.5f * v0;
    float3 b = midpoint + width * 0.5f * v0;
    addBlade(a, b, midpoint, typeId, up1, normal, tangent, triStream);

    a = midpoint + width * 0.5f * v1;
    b = midpoint - width * 0.5f * v1;
    addBlade(a, b, midpoint, typeId, up2, normal, tangent, triStream);

    a = midpoint - width * 0.5f * v2;
    b = midpoint + width * 0.5f * v2;
    addBlade(a, b, midpoint, typeId, up3, normal, tangent, triStream);
}

void wheat(float3 midpoint, uint typeId, float2 size, float3 normal, float4 tangent, inout TriangleStream<GS_OUTPUT> triStream)
{
    float angle = 1.0472;
    float3 v0 = normalize(float3(cos(0), sin(0), 0));
    float3 v1 = normalize(float3(cos(angle), sin(angle), 0));
    float3 v2 = normalize(float3(-cos(angle), sin(angle), 0));

    float3 up = float3(0,0,size.y);
    float3 a = midpoint - size.x * 0.5f * v0;
    float3 b = midpoint + size.x * 0.5f * v0;
    addBlade(a, b, midpoint, typeId, up, normal, tangent, triStream);

    a = midpoint + size.x * 0.5f * v1;
    b = midpoint - size.x * 0.5f * v1;
    addBlade(a, b, midpoint, typeId, up, normal, tangent, triStream);

    a = midpoint - size.x * 0.5f * v2;
    b = midpoint + size.x * 0.5f * v2;
    addBlade(a, b, midpoint, typeId, up, normal, tangent, triStream);
}

[maxvertexcount(18)]
void mainGS( point VS_OUTPUT v[1], inout TriangleStream<GS_OUTPUT> triStream )
{
    float3 midpoint = v[0].position.xyz;
    float width = v[0].size.x;
    float height = v[0].size.y;
    uint typeId = v[0].typeId;
    float3 normal = v[0].normal;
    float4 tangent = float4(cross(normal, cross(normal, float3(1, 0, 0))) ,1);

    float angle = 1.0472;


    float3 up1;
    float3 up2;
    float3 up3;

    //[flatten]
    if(bushData[typeId].type == 1)
    {
        wheat(midpoint, typeId, v[0].size, normal, tangent, triStream);
    }
    else
    {
        bush(midpoint, typeId, v[0].size, normal, tangent, triStream);
    }
}

PS_OUTPUT mainPS(GS_OUTPUT p, bool isFrontFace: SV_IsFrontFace)
{
    INITIALIZE_OUTPUT(PS_OUTPUT, o)

    //p.normal *= (1 - isFrontFace * 2);

#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif

    half4 albedo = (half4)_albedoTexture.Sample(grassSampler, float2(p.uv.x, p.uv.y));
    float2 packedNormal = _normalTexture.Sample(grassSampler, float2(p.uv.x, p.uv.y));
    half4 rough = (half4)_roughTexture.Sample(grassSampler, float2(p.uv.x, p.uv.y));

    float alpha = albedo.a;

    float3 normal = unpackNormal(packedNormal);
    float3x3 TBN = makeTBN(p.normal, p.tangent);
    normal = normalize(mul(normal, TBN));
    float metallic = rough.r;
    float roughness = rough.g;
    float occlusion = rough.b;    

    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = occlusion;

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, albedo.rgb, metallic.rrr);
    float3 viewDir = WorldSpaceViewDir(p.position.xyz);    

    float2 terrainUv = p.position.xy / mapSize;
    float4 terrainColor = _terrainTexture.Sample(defaultSampler, terrainUv);

   albedo = lerp(terrainColor, albedo, p.uv.z);

    albedo = pow(abs(albedo), 2.2);
    float4 c = BRDF(albedo, specColor, roughness, metallic, normal, viewDir, gi, shadow);
    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    c.rgb += fow.rgb;
    
    float dist = distance(worldSpaceCameraPos, p.position.xyz);
    float distance_alpha = 1.0f - saturate((dist - (grassDistance - grassDistance * 0.3f)) / (grassDistance * 0.3f)); 
    
    o.color.rgb = c.rgb * exposure.r;
    o.color.a = alpha * distance_alpha;

#if defined(_FOG_OF_WAR) && !defined(_DONT_USE_FOW)
    o.color.rgb = applyFogOwWar(o.color.rgb, fogColor, fow.a);  
#endif
#ifdef _FOG
    applyHorizontalFog(p.position, o.color.rgb);
    applyVerticalFog(p.position, o.color.rgb);
    o.color.rgb = lerp(o.color.rgb, fogColor, p.fogFactor);
#endif    

    //o.color = float4(p.normal,1);

    if(o.color.a < 0.3f)
    {
        //discard;
    }    
    o.emission = 0;
    return o;
}
