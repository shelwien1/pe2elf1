#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"
#include "common/light.hlsl"


CBUFFER_START(Data, 0)
    float4 roadColor;
    float4 emissionColor;
    float emissionPower;
    float roadFrom;
    float roadTo;
CBUFFER_END

struct v2v
{
    float4 position : POSITION;
    float4 color: COLOR;
};

struct v2p
{
    float4 position : SV_POSITION;
    float4 color: COLOR;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.position = mul(float4(v.position.rgb,1), matrixViewProj);
    o.color = v.color;
    return o;
}

struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 emission: SV_Target1;
};

PS_OUTPUT mainPS(v2p p)
{
    INITIALIZE_OUTPUT(PS_OUTPUT, result)
    
    float4 color = roadColor;

    float showFactor = (p.color.b >= roadFrom && p.color.b <= roadTo) ? 1 : 0;
    color.a *= p.color.a * showFactor;
    result.color = color;
    result.emission = float4(emissionColor.rgb * emissionPower, emissionColor.a * p.color.a * showFactor);
    return result;
}