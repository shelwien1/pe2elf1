#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"


#define texSample(inputTexture, sampler, uv) (inputTexture.Sample(sampler, uv))

#include "common/terrain_base.hlsl"

#define _DISABLEHEIGHTBLENDING

Texture2D<float> _heightMap : register(t10);
Texture2D<float2> _normalMap : register(t11);

#ifdef _DEBUG_SHOW_PATHBLOCKS
Texture2D<half4> _pathBlockLight : register(t20);
Texture2D<half4> _pathBlockMedium : register(t21);
Texture2D<half4> _pathBlockHeavy : register(t22);
Texture2D<half4> _pathBlockLevitating : register(t23);
Texture2D<half4> _pathRoad : register(t24);
Texture2D<half4> _waterDust : register(t25);
#endif

Texture2D<uint> _dataMap : register(t30);
SamplerState heightMapSampler : register(s1);


struct v2p
{
    float4 position : POSITION;
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float2 splat_uv: TEXCOORD1;
    float4 viewSpacePos: TEXCOORD2;
    float4 lightViewPosition[4] : TEXCOORD3;
    float3 normal: NORMAL;
    float4 debugColor: COLOR0;
    float2 fowUV: TEXCOORD7;
#ifdef _FOG
    float fogFactor : FOG;
#endif
};

struct v2v
{
    float3 position : POSITION;
};

struct TerrainData
{
    float2 tileOffset;
    float2 tileScale;
};

StructuredBuffer<TerrainData> terrainData : register(t31);

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(v2v v, uint id : SV_InstanceID)
{
    INITIALIZE_OUTPUT(v2p, o);

    float2 tileOffset = terrainData[id].tileOffset;
    float2 tileScale = terrainData[id].tileScale;

    float4 position = float4(v.position.xy * tileScale + tileOffset, 0, 1); 
    float height = _heightMap[position.xy] * terrainHeight;
    float2 normal = _normalMap[position.xy]; 

    position.z = height;
    o.position = position;
    o.pixelPosition = mul(position, matrixViewProj);
    //o.pixelPosition = mul(position, matrixView);
    //o.pixelPosition = mul(o.pixelPosition, matrixProj);
    o.uv = position.xy / float2(16,-16);

    o.viewSpacePos = mul(o.position, matrixView);
    o.lightViewPosition[0] = mul(o.position, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(o.position, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(o.position, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(o.position, matrix_shadowVP[3]);

    o.splat_uv = position.xy / terrainSize;
    o.fowUV = float2(position.x, position.y) / float2(terrainSize, terrainSize);
    //o.normal = normalize(position.xyz / float3(512,512,256));
    o.normal = unpackNormal(normal);
    //o.normal.y = -o.normal.y;
#ifdef _FOG
    float3 cameraPosition = mul(o.position, matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));

#endif
    return o;
}


//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 silhouette:  SV_Target2;
};

PS_OUTPUT mainPS(v2p i) 
{
    if((_dataMap[i.position.xy] & 1) != 0)
        discard;

    //return half4(1,1,1,1);

    float3x3 TBN = makeTBN(i.normal, float4(1, 0, 0, 1));

    TerrainConfig config = (TerrainConfig)0;
    config.TBN = TBN;
    SplatLayer l = GetSplatLayer(i.splat_uv, i.uv, i.normal);
 
    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    //gi.occlusion = l.Occlusion;
    gi.occlusion = (half)pow(abs(l.Occlusion), 2.2);

    float3 viewDir = WorldSpaceViewDir(i.position.xyz);
    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, l.Albedo, l.Metallic);
    float3 normal = normalize(mul(l.Normal, TBN));
    //normal = normalize(i.normal);
    
#ifdef _SHADOW    
    //float shadow = saturate(shadowMapping(i.lightViewPosition, dot(normal, gi.light.dir)) + shadowOpacity);
    float shadow = saturate(shadowMapping2(i.viewSpacePos, i.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif    
    l.Albedo = (half3)pow(abs(l.Albedo), 2.2);
    float4 c = BRDF(l.Albedo, specColor, l.Roughness, l.Metallic, normal, viewDir, gi, shadow);
    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - i.fowUV.yx);
    c.rgb += fow.rgb;
//_pathBlockLevitating
#ifdef _DEBUG_SHOW_PATHBLOCKS
	if ((_dataMap[i.position.xy] & (1 << 7)) != 0)
	{
		half4 light = _pathRoad.Sample(defaultSampler, float2(i.position.x, 1 - i.position.y));
		c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
	}
	if ((_dataMap[i.position.xy] & (1 << 5)) != 0)
	{
		half4 light = _waterDust.Sample(defaultSampler, float2(i.position.x, 1 - i.position.y));
		c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
	}
    if((_dataMap[i.position.xy] & (1<<4)) != 0)
    {
        half4 light = _pathBlockLevitating.Sample(defaultSampler, float2(i.position.x, 1-i.position.y));
        c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
    }
    if((_dataMap[i.position.xy] & (1<<3)) != 0)
    {
        half4 light = _pathBlockHeavy.Sample(defaultSampler, float2(i.position.x, 1-i.position.y));
        c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
    }
    if((_dataMap[i.position.xy] & (1<<2)) != 0)
    {
        half4 light = _pathBlockMedium.Sample(defaultSampler, float2(i.position.x, 1-i.position.y));
        c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
    }
    if((_dataMap[i.position.xy] & (1<<1)) != 0)
    {
        half4 light = _pathBlockLight.Sample(defaultSampler, float2(i.position.x, 1-i.position.y));
        c.rgb = light.a * light.rgb + (1 - light.a) * c.rgb;
    }
#endif

    
    float3 color = c.rgb * exposure.r;
    
#ifdef _FOG_OF_WAR
    color = applyFogOwWar(color, fogColor, fow.a);    
#endif

#ifdef _FOG
    applyHorizontalFog(i.position, color);
    applyVerticalFog(i.position, color);
    color = lerp(color, fogColor, i.fogFactor);
#endif

    float3 c1 = debugCascadeColor2(i.viewSpacePos, i.lightViewPosition);


    INITIALIZE_OUTPUT(PS_OUTPUT, result)
    //result.color = float4(i.normal,1);
    result.color = float4(color, 1);        
    result.silhouette.a = 1;
    return result;

    //return half4(color, 1);
}


// ===== ShadowMap ==============

CBUFFER_START(TerrainTileData, 0)
    float2 terrainTileOffset;
    float2 terrainTileScale;
CBUFFER_END

struct VS_OUTPUT_SHADOWMAP_INSTANCING
{
  float4 position : POSITION;
  uint iSplit : TEXTURE0;
  float4 worldPosition : TEXCOORD1;
};

struct GS_OUTPUT_SHADOWMAP
{
  float4 vPos : SV_POSITION;
  float4 worldPosition : TEXCOORD0;
  uint RTIndex : SV_RenderTargetArrayIndex;
};

VS_OUTPUT_SHADOWMAP_INSTANCING shadowVS(appdata_base v, uint id : SV_InstanceID)
{
    INITIALIZE_OUTPUT(VS_OUTPUT_SHADOWMAP_INSTANCING, o);
    float2 tileOffset = terrainTileOffset;
    float2 tileScale = terrainTileScale;

    float4 position = float4(v.position.xy * tileScale + tileOffset, 0, 1); 
    float height = _heightMap[position.xy] * terrainHeight;
    position.z = height;

    o.iSplit = firstSplitIndex + id;
    o.worldPosition = position;
    o.position = mul(position, matrixViewProj);
    o.position = mul(o.position, matrix_shadowVP[o.iSplit]);
    return o;
}

[maxvertexcount(3)]
void shadowGS( triangle VS_OUTPUT_SHADOWMAP_INSTANCING In[3], inout TriangleStream<GS_OUTPUT_SHADOWMAP> TriStream )
{
    GS_OUTPUT_SHADOWMAP Out;
    // set render target index
    Out.RTIndex = In[0].iSplit;
    // pass vertices through
    Out.vPos = In[0].position;
    Out.worldPosition = In[0].worldPosition;
    TriStream.Append(Out);

    Out.vPos = In[1].position;
    Out.worldPosition = In[1].worldPosition;
    TriStream.Append(Out);

    Out.vPos = In[2].position;
    Out.worldPosition = In[2].worldPosition;
    TriStream.Append(Out);

    TriStream.RestartStrip();
}

void shadowPS(GS_OUTPUT_SHADOWMAP i)
{
    if((_dataMap[i.worldPosition.xy] & 1) != 0)
        discard;
}