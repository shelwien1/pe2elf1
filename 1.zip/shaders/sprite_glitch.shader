#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"
#include "common/noise.hlsl"


Texture2D<float4> _mainTexture : register(t0);
SamplerState sampler_mainTexture : register(s0);

Texture2D<float4> _noiseTexture : register(t1);
SamplerState sampler_noiseTexture : register(s1);

CBUFFER_START(Data, 0)
    float2 textureSize;
    float2 noiseTextureSize;
CBUFFER_END

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.pixelPosition = mul(mul(v.position, matrix_ObjectToWorld), matrixViewProj);
    o.uv = v.uv;
    return o;
}

#define tex2D(tex, uv) (tex.Sample(sampler##tex, uv));
static float interval = 10.0;

float random(float2 c)
{
    return frac(sin(dot(c.xy ,float2(12.9898,78.233))) * 43758.5453);
}

float4 mainPS(v2p p) : SV_TARGET
{
    float4 color = _mainTexture.Sample(defaultSampler, p.uv);

    float2 uv = p.uv;
    float2 block = floor(uv * 16);
    float2 uv_noise = block / noiseTextureSize;
    uv_noise += float2(random(time.xx) * 2.0 - 1.0, random(time.xx * 2) * 2.0 - 1.0);
 
    float block_thresh = pow(frac(time * 3.095 ), 3.0) * 0.3;
	float line_thresh = pow(frac(time * 2236.04153), 3.0) * 0.2;    

    float2 uv_r = uv, uv_g = uv, uv_b = uv;

    float4 noise = tex2D(_noiseTexture, uv_noise);
    float4 noise_y = tex2D(_noiseTexture, float2(uv_noise.y, 0.0));

    if(noise.r < block_thresh || 
       noise_y.g < line_thresh)
       {
           float2 dist = (frac(uv_noise) - 0.5) * 0.6;
           uv_r += dist * -0.5;
           uv_g += dist * 0.3;
           uv_b += dist * -0.525;
       }
    float4 red = _mainTexture.Sample(defaultSampler, uv_r);
    float4 green = _mainTexture.Sample(defaultSampler, uv_g);
    float4 blue = _mainTexture.Sample(defaultSampler, uv_b);

    float4 glitched_color = float4(red.r, green.g, blue.b, saturate(red.a + green.a + blue.a));

	if (noise.g < block_thresh)
    {
		glitched_color.rgb = glitched_color.ggg;    
    }
	if (noise_y.b * 1.5 < line_thresh)
    {
		glitched_color.rgb = float3(0, dot(color.rgb, 0.5), dot(color.rgb, 0.4f));     
    }

    float strength = smoothstep(interval - 1.5, interval, interval - fmod(time, interval));
    color.rgb = lerp(color.rgb, glitched_color.rgb, strength);

    color.rgb = color.rgb * lerp(1.0,saturate(scanLine(p.uv + float2(0, -frac(time * 0.02)), textureSize.y / 1.5f )), 0.4f + sin(time * 5.05)*0.1f);
    return color;
}
