#include "common/baseCG.hlsl"
#include "common/PBSLighting.hlsl"
#include "common/standardCore.hlsl"
#include "common/light.hlsl"
#include "common/BRDF.hlsl"
#include "common/shadowMapping.hlsl"
#include "common/toneMapping.hlsl"
#include "common/fow.hlsl"


Texture2D<float4> _normal0 : register(t0);
Texture2D<float4> _normal1 : register(t1);
Texture2D<float4> _noiseMap : register(t2);
Texture2D<float4> _foam : register(t3);
Texture2D<float> _depthBuffer : register(t12);
SamplerState riverSampler : register(s1);

CBUFFER_START(Data, 0)
    float4 shallowColor;
    float4 deepColor;
    float4 waterData;
    float waterDepth;
    float metallic;
    float roughness;
    float foamDistance;
	float foamTiling;
    float foamSpeed;
    float foamStrength;
CBUFFER_END


struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float3 position : POSITION0;
    float4 pos : POSITION1;
    float2 uv : TEXCOORD0;
    float4 viewSpacePos : TEXCOORD1;
    float4 lightViewPosition[4] : TEXCOORD2;    
    float3 fowUV: TEXCOORD6;
#ifdef _FOG
    float fogFactor : FOG;
#endif
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    float4 pos = mul(float4(v.position.xyz,1), matrix_ObjectToWorld);
    o.position = pos.xyz;
    o.pixelPosition = mul(pos, matrixViewProj);
    o.pos = o.pixelPosition;
    
    o.uv = v.uv;

    o.fowUV.xy = pos.xy / terrainSize;
    o.fowUV.z = saturate(1-(pos.z - _heightMap[pos.xy] * terrainHeight) / 10);
#ifdef _FOG
    float3 cameraPosition = mul(float4(o.position,1), matrixView);
    o.fogFactor = 1.0f - saturate((fogEnd - (-cameraPosition.z)) / (fogEnd - fogStart));
#endif

    o.viewSpacePos = mul(pos, matrixView);
    o.lightViewPosition[0] = mul(pos, matrix_shadowVP[0]);
    o.lightViewPosition[1] = mul(pos, matrix_shadowVP[1]);
    o.lightViewPosition[2] = mul(pos, matrix_shadowVP[2]);
    o.lightViewPosition[3] = mul(pos, matrix_shadowVP[3]);

    return o;
}

float4 calculateFoam(float2 uv, float dstFromShore)
{
    float2 foamMaskOffset = float2(-0.021, 0.07) * foamSpeed * 0.01f * time.x;
    float foamMask = _foam.Sample(defaultSampler, uv * foamTiling + foamMaskOffset).r;
    float2 foamMaskOffset2 = float2(0.021, -0.07) * foamSpeed * 0.01f * time.x;
    float foamMask2 = _foam.Sample(defaultSampler, uv * foamTiling + foamMaskOffset2).r;
    foamMask = foamMask * foamMask2;
    return saturate(1-dstFromShore) * foamMask;
}

float depthFade(float distance, float4 vertexPos)
{
    float3 screenPos = vertexPos.xyz / vertexPos.w; 
    float2 uv = 0.5f * float2(screenPos.x,-screenPos.y) + 0.5f;

    float depth = _depthBuffer.Sample(defaultSampler, uv).r;
    float d1 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - depth * (cameraFarPlane - cameraNearPlane));
    float d2 = cameraNearPlane * cameraFarPlane / (cameraFarPlane - screenPos.z * (cameraFarPlane - cameraNearPlane));

    float d = saturate((d1 - d2) / distance);

    float contrastPower = 2;
    float res = 0.5 * pow(saturate(2 * ((d > 0.5) ? 1 - d : d)), contrastPower);
    res = (d > 0.5) ? 1-res : res;
    return res;
}

float4 mainPS(v2p p) : SV_TARGET
{
    float2 waterDir = waterData.xy;
    float waterSpeed = waterData.z;
    float waterTiling = waterData.w;
    float speed = waterTiling * 0.001 * waterSpeed;

    float3 viewDir = WorldSpaceViewDir(p.position.xyz);    
    float height = _heightMap.Sample(defaultSampler, p.position.xy / terrainSize) * terrainHeight;    
    float2 uv = p.position.xy / terrainSize * waterTiling;

    float phase0 = time * speed;
    float phase1 = -time * speed + 0.5;

    float2 uv0 = uv + waterDir * phase0;
    float2 uv1 = uv + waterDir.yx*0.5 + waterDir * phase1;

    float noise = saturate(_noiseMap.Sample(defaultSampler, uv).r);    

    float3 normalT0 = unpackNormal(_normal0.Sample(riverSampler, uv0).xy);
    float3 normalT1 = unpackNormal(_normal1.Sample(riverSampler, uv1).xy);

    float3 normal = normalize(float3 (normalT0.xy + normalT1.xy, normalT0.z * normalT1.z));

    float fade = depthFade(waterDepth, p.pos);
    float4 color = lerp(shallowColor, deepColor, fade);
    float3 albedo = color.rgb;
    float alpha = color.a;

    float3 specColor = lerp(colorSpaceDielectricSpec.rgb, albedo, metallic);

    BaseGI gi;
    gi.light.color = directLightColor.rgb;
    gi.light.dir = -normalize(directLightDir);
    gi.occlusion = 1;

#ifdef _USE_FOAM
    float4 foam = calculateFoam(p.position.xy / terrainSize, depthFade(foamDistance, p.pos)) * foamStrength;
    albedo = lerp(albedo, float3(1,1,1), foam);
    float shoreLineFade = saturate(depthFade(0.1, p.pos));
    alpha = lerp(alpha, 1.0f, foam) * shoreLineFade;
#endif

#if defined(_SHADOW) && defined(_SHADOW_RECEIVE)
    float shadow = saturate(shadowMapping2(p.viewSpacePos, p.lightViewPosition) + shadowOpacity);
#else
    float shadow = 1;
#endif

    albedo = pow(abs(albedo), 2.2);
    float4 c = BRDF(albedo, specColor, roughness, metallic, normal, viewDir, gi, shadow);

    float4 fow = _fogOfWar.Sample(fogOfWarMapSampler, float2(1,1) - p.fowUV.yx);
    c.rgb += fow.rgb * p.fowUV.z;

#if defined(_FOG_OF_WAR) && !defined(_DONT_USE_FOW)
    c.rgb = applyFogOwWar(c.rgb, fogColor, fow.a);  
#endif
#ifdef _FOG
    applyHorizontalFog(float4(p.position,1), c.rgb);
#ifndef _DONT_USE_VERTICAL_FOG
    applyVerticalFog(float4(p.position,1), c.rgb);
#endif
    c.rgb = lerp(c.rgb, fogColor, p.fogFactor);
#endif
    
    return float4(c.rgb, alpha);
}
