#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"


Texture2D<float4> _mainTexture : register(t0);

//--------------------------------------------------------------------------------------
struct v2v
{
    float4 position : POSITION;
#ifdef _USE_UV
    float2 uv : TEXCOORD0;
#endif
#ifdef _VERTEX_COLOR
    float4 color: COLOR;
#endif        
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
};

//--------------------------------------------------------------------------------------
// Nothing special here
v2p mainVS(v2v v) 
{
 INITIALIZE_OUTPUT(v2p, o);
    o.pixelPosition = mul(mul(v.position, matrix_ObjectToWorld), matrixViewProj);
#ifdef _USE_UV
    o.uv = v.uv;
#endif
#ifdef _VERTEX_COLOR
    o.color = saturate(v.color);
#else
    o.color = float4(1,1,1,1);
#endif
    
    return o;
}

//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------

float3 YUVToRGB(float3 yuv) 
{
  // BT.601 coefs
  static const float3 yuvCoef_r = { 1.164f, 0.000f, 1.596f };
  static const float3 yuvCoef_g = { 1.164f, -0.392f, -0.813f };
  static const float3 yuvCoef_b = { 1.164f, 2.017f, 0.000f };
  yuv -= float3(0.0625f, 0.5f, 0.5f);
  return saturate(float3( 
    dot( yuv, yuvCoef_r ),
    dot( yuv, yuvCoef_g ),
    dot( yuv, yuvCoef_b )
    ));
}

float4 mainPS(v2p p) : SV_Target 
{
    float4 color = float4(1,1,1,1);
#ifdef _USE_UV
    color *= _mainTexture.Sample(defaultSampler, p.uv);
#endif
#ifdef _VERTEX_COLOR
    color *= p.color;
#endif
    //return color;

  float y = _mainTexture.Sample(defaultSampler, float2(p.uv.x, p.uv.y * 0.5)).r;
  float u = _mainTexture.Sample(defaultSampler, float2(p.uv.x * 0.5, 0.50 + p.uv.y * 0.25)).r;
  float v = _mainTexture.Sample(defaultSampler, float2(p.uv.x * 0.5, 0.75 + p.uv.y * 0.25)).r;
  return float4(YUVToRGB(float3(y,u,v)), 1.f);
}