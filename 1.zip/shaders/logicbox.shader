#include "common/baseCG.hlsl"

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float4 position : POSITION;
};

CBUFFER_START(Data, 0)
    float4 color;
CBUFFER_END

//--------------------------------------------------------------------------------------
// Vertex Shader
//--------------------------------------------------------------------------------------
v2p mainVS(appdata_base v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.position = mul(float4(v.position.xyz, 1), matrix_ObjectToWorld);
    o.pixelPosition = mul(mul(float4(v.position.xyz, 1), matrix_ObjectToWorld), matrixViewProj);
    return o;
}

//--------------------------------------------------------------------------------------
// Pixel Shader
//--------------------------------------------------------------------------------------
float4 mainPS(v2p p) : SV_TARGET
{
    return color;
}