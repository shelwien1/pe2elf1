#include <common/shaderVariables.hlsl>
#define M_PI (3.1415926535897932384626433832795)

Texture2D<float4> _texture : register(t0);
Texture2D<float4> _noiseTexture : register(t1);
SamplerState defaultSampler : register(s0);
SamplerState noiseSampler : register(s1);

CBUFFER_START(Data, 0)
    float2 textureSize;    
    float timeMultiplier;    
CBUFFER_END

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float qScanLine (float2 uv, float n) {
	return abs (cos (uv.y*M_PI*n)) ; 
}
float4 v2DNoiseSample (float2 gPos) 
{
	float2 nPos = float2(fmod(gPos.x+time*9.66,1.0), fmod(gPos.y+time*7.77,1.0));		
	return _noiseTexture.Sample(defaultSampler, nPos);
}

float4 v1DNoiseSample (float idx, float s) {	
	return _noiseTexture.Sample(defaultSampler, float2(fmod(idx, 1.0), fmod(time*s, 1.0)));
}

float q2DNoiseSample (float2 gPos) {
 	float4 nPnt = v2DNoiseSample (gPos);
	return nPnt.x;
}

float q1DNoiseSample (float idx, float s){
	float4 nPnt = v1DNoiseSample (idx, s);
	return nPnt.x;
}

float2 vScanShift (float2 uv, float q, float dy, float dt) {
	return float2(uv.x + q1DNoiseSample (uv.y*dy, dt)*q, uv.y);
}

float4 cSignalNoise (float4 c,float q, float2 gPos) {
	return c*(1.0 - q) + q*q2DNoiseSample(gPos);
}

float4 oldTvNoise(PS_INPUT p)
{
    float2 cPos = p.uv;
    float qNoise = q1DNoiseSample(0.005,0.005);
    cPos = vScanShift (cPos, 0.004, 0.02, 0.01);
    
    float4 color = _texture.Sample(defaultSampler, cPos);
    color = cSignalNoise (color, qNoise * 0.8, p.uv) * color.a;
    color = color * qScanLine (p.uv, 148.0);
    return color;
}

float4 tex2D(Texture2D<float4> tex, float2 uv)
{
    return tex.Sample(noiseSampler, uv);
}


float4 glitch(PS_INPUT p)
{
    float2 uv = p.uv;
    float2 block = floor(uv * 64);
    float2 uv_noise = block / 512;
    uv_noise += floor(time * float2(1234.04, 3543.03)) / 512;

    float block_thresh = pow(frac(time * 5.05 ), 2.0) * 0.5;
	float line_thresh = pow(frac(time * 2236.04153), 3.0) * 0.4;    

    float2 uv_r = uv, uv_g = uv, uv_b = uv;

    float4 noise = tex2D(_noiseTexture, uv_noise);
    float4 noise_y = tex2D(_noiseTexture, float2(uv_noise.y, 0.0));

    if(noise.r < block_thresh || 
       noise_y.g < line_thresh)
       {
           float2 dist = (frac(uv_noise) - 0.5) * 0.3;
           uv_r += dist * 0.1;
           uv_g += dist * 0.2;
           uv_b += dist * 0.125;
       }
    float4 red = _texture.Sample(defaultSampler, uv_r);
    float4 green = _texture.Sample(defaultSampler, uv_g);
    float4 blue = _texture.Sample(defaultSampler, uv_b);

    float4 glitched_color = float4(red.r, green.g, blue.b, saturate(red.a + green.a + blue.a));

	// loose luma for some blocks
	if (noise.g < block_thresh)
    {
		glitched_color.rgb = glitched_color.ggg;    
    }

	// discolor block lines
	if (noise_y.b * 3.5 < line_thresh)
    {
		glitched_color.rgb = float3(0, 0.5, 0.4);//dot(color.rgb, 1.0));     
    }
    float qNoise = q1DNoiseSample(0.005,0.005);
    glitched_color = cSignalNoise (glitched_color, qNoise * 0.4, p.uv) * glitched_color.a;

    float4 color = _texture.Sample(defaultSampler, uv);

    color = lerp(color, glitched_color, timeMultiplier);

    color.a = color.a *  saturate(qScanLine (p.uv + float2(0, -frac(time * 0.009f)), textureSize.y / 3 ));
    return color;
}

float4 mainPS(PS_INPUT p) : SV_Target
{
    //return oldTvNoise(p);
    return glitch(p);
}