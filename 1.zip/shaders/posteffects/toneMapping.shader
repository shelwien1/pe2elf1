static const float gamma = 2.2;
static const float pureWhite = 1.0;

Texture2D<float4> _texture : register(t0);
Texture2D<float4> _bloom : register(t1);
SamplerState defaultSampler : register(s0);

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};


float3 LinearTosRGB(in float3 color)
{
    float3 x = color * 12.92f;
    float3 y = 1.055f * pow(saturate(color), 1.0f / 2.4f) - 0.055f;

    float3 clr = color;
    clr.r = color.r < 0.0031308f ? x.r : y.r;
    clr.g = color.g < 0.0031308f ? x.g : y.g;
    clr.b = color.b < 0.0031308f ? x.b : y.b;

    return clr;
}

float3 ToneMapFilmicALU(in float3 color)
{
    color = max(0, color - 0.004f);
    color = (color * (6.2f * color + 0.5f)) / (color * (6.2f * color + 1.7f)+ 0.06f);
    return color;
}

float3 Reinhard(float3 color)
{
	// Reinhard tonemapping operator.
	// see: "Photographic Tone Reproduction for Digital Images", eq. 4
    float luminance = dot(color, float3(0.2126, 0.7152, 0.0722));
    float mappedLuminance = (luminance * (1.0 + luminance / (pureWhite * pureWhite))) / (1.0 + luminance);

	// Scale color by ratio of average luminances.
    float3 mappedColor = (mappedLuminance / luminance) * color;
    mappedColor = pow(abs(mappedColor), 1.0 / gamma);
    
    return mappedColor;
}

float3 Uncharted2ToneMapping(float3 color)
{
	float A = 0.15;
	float B = 0.50;
	float C = 0.10;
	float D = 0.20;
	float E = 0.02;
	float F = 0.30;
	float W = 11.2;
	float exposure = 2.;
	color *= exposure;
	color = ((color * (A * color + C * B) + D * E) / (color * (A * color + B) + D * F)) - E / F;
	float white = ((W * (A * W + C * B) + D * E) / (W * (A * W + B) + D * F)) - E / F;
	color /= white;
	color = pow(color, 1. / gamma);
	return color;
}

float4 mainPS(PS_INPUT p) : SV_Target
{
    float3 output;
    float4 color = _texture.Sample(defaultSampler, p.uv);

#ifdef _USE_BLOOM
    color.rgb += _bloom.Sample(defaultSampler, p.uv).rgb;
#endif    

    //output = Uncharted2ToneMapping(color);
    output = LinearTosRGB(color.rgb);
    //output = Reinhard(color);
    //output = ToneMapFilmicALU(color);
    //output = Reinhard( _bloom.Sample(defaultSampler, p.uv).rgb);
    return float4(output, color.a);
}