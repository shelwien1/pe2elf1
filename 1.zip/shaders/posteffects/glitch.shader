#include <common/shaderVariables.hlsl>
#define M_PI (3.1415926535897932384626433832795)

Texture2D<float4> _texture : register(t0);
Texture2D<float4> _noiseTexture : register(t1);
SamplerState defaultSampler : register(s0);
SamplerState noiseSampler : register(s1);

CBUFFER_START(Data, 0)
    float2 textureSize;    
    float2 noiseTextureSize;
    float glitchSize;
    float glitchStrength;
    float lineThreshModifier;
CBUFFER_END

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float4 tex2D(Texture2D<float4> tex, float2 uv)
{
    return tex.Sample(noiseSampler, uv);
}

float4 mainPS(PS_INPUT p) : SV_Target
{
    float2 uv = p.uv;
    float2 block = floor(uv * (textureSize / glitchSize));
    float2 uv_noise = block / noiseTextureSize;
    uv_noise += floor(time * float2(1234.04, 3543.03)) / noiseTextureSize;

    float block_thresh = pow(frac(time * 5.05 ), 2.0) * 0.5;
	float line_thresh = pow(frac(time * 2236.04153), 3.0) * 0.4;    

    float2 uv_r = uv, uv_g = uv, uv_b = uv;

    float4 noise = tex2D(_noiseTexture, uv_noise);
    float4 noise_y = tex2D(_noiseTexture, float2(uv_noise.y, 0.0));

    if(noise.r < block_thresh || 
       noise_y.g < line_thresh)
       {
           float2 dist = (frac(uv_noise) - 0.5) * 0.3;
           uv_r += dist * 0.1;
           uv_g += dist * 0.2;
           uv_b += dist * 0.125;
       }
    float4 red = _texture.Sample(defaultSampler, uv_r);
    float4 green = _texture.Sample(defaultSampler, uv_g);
    float4 blue = _texture.Sample(defaultSampler, uv_b);

    float4 color = _texture.Sample(defaultSampler, p.uv);
    float4 glitched_color = float4(red.r, green.g, blue.b, saturate(red.a + green.a + blue.a));

	// loose luma for some blocks
	if (noise.g < block_thresh)
    {
		glitched_color.rgb = glitched_color.ggg;    
    }

	// discolor block lines
	if (noise_y.b * 3.5 < line_thresh * lineThreshModifier)
    {
		glitched_color.rgb = float3(0, 0.5, 0.4);//dot(color.rgb, 1.0));     
    }

    return lerp(color, glitched_color, glitchStrength);
}