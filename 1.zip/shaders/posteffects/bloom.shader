Texture2D<float4> _texture : register(t0);
Texture2D<float4> _additiveTexture : register(t1);

SamplerState defaultSampler : register(s0);

cbuffer data : register(b0) 
{
    float2 inverseResolution;
    float streakLength;
    float radius;
    float strength;
    float bloomThreshold = 1.0f;
}

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

//Just an average of 4 values.
float4 Box4(float4 p0, float4 p1, float4 p2, float4 p3)
{
	return (p0 + p1 + p2 + p3) * 0.25f;
}

half Luminance( half3 linearColor )
{
	return dot( linearColor, half3( 0.3, 0.59, 0.11 ) );
}

float4 mainPS(PS_INPUT p) : SV_Target
{
    return float4(1,0,1,1);
}

float4 bloomSetupPS(PS_INPUT p) : SV_Target
{
    float4 color = _texture.Sample(defaultSampler, p.uv);
    color.rgb = min(float3(256 * 256, 256 * 256, 256 * 256), color.rgb);
    
    half3 c = color.rgb;

    half brightness = max(c.r, max(c.g, c.b));
    half contribution = max(0, brightness - bloomThreshold);
    contribution /= max(brightness, 0.00001);
    return float4(c * contribution, 1);
}

float4 downsamplePS(PS_INPUT p) : SV_Target
{
    float2 offset = float2(streakLength * inverseResolution.x, inverseResolution.y);
        
    float4 c0  = _texture.Sample(defaultSampler, p.uv + float2(-2, -2) * offset);
    float4 c1  = _texture.Sample(defaultSampler, p.uv + float2( 0, -2) * offset);
    float4 c2  = _texture.Sample(defaultSampler, p.uv + float2( 2, -2) * offset);
    float4 c3  = _texture.Sample(defaultSampler, p.uv + float2(-1, -1) * offset);
    float4 c4  = _texture.Sample(defaultSampler, p.uv + float2( 1, -1) * offset);
    float4 c5  = _texture.Sample(defaultSampler, p.uv + float2(-2,  0) * offset);
    float4 c6  = _texture.Sample(defaultSampler, p.uv);
    float4 c7  = _texture.Sample(defaultSampler, p.uv + float2( 2, 0) * offset);
    float4 c8  = _texture.Sample(defaultSampler, p.uv + float2(-1, 1) * offset);
    float4 c9  = _texture.Sample(defaultSampler, p.uv + float2( 1, 1) * offset);
    float4 c10 = _texture.Sample(defaultSampler, p.uv + float2(-2, 2) * offset);
    float4 c11 = _texture.Sample(defaultSampler, p.uv + float2( 0, 2) * offset);
    float4 c12 = _texture.Sample(defaultSampler, p.uv + float2( 2, 2) * offset);

    return (Box4(c0, c1, c5, c6) * 0.125f +
        Box4(c1, c2, c6, c7) * 0.125f +
        Box4(c5, c6, c10, c11) * 0.125f +
        Box4(c6, c7, c11, c12) * 0.125f +
        Box4(c3, c4, c8, c9) * 0.5f);
}

float4 upsampleLuminancePS(PS_INPUT p) : SV_Target
{
    //return _texture.Sample(defaultSampler, p.uv);
    float2 offset = float2(streakLength * inverseResolution.x, inverseResolution.y) * radius;

    float4 c0 = _texture.Sample(defaultSampler, p.uv + float2(-1, -1) * offset);
    float4 c1 = _texture.Sample(defaultSampler, p.uv + float2(0, -1) * offset);
    float4 c2 = _texture.Sample(defaultSampler, p.uv + float2(1, -1) * offset);
    float4 c3 = _texture.Sample(defaultSampler, p.uv + float2(-1, 0) * offset);
    float4 c4 = _texture.Sample(defaultSampler, p.uv);
    float4 c5 = _texture.Sample(defaultSampler, p.uv + float2(1, 0) * offset);
    float4 c6 = _texture.Sample(defaultSampler, p.uv + float2(-1,1) * offset);
    float4 c7 = _texture.Sample(defaultSampler, p.uv + float2(0, 1) * offset);
    float4 c8 = _texture.Sample(defaultSampler, p.uv + float2(1, 1) * offset);

    //Tentfilter  0.0625f    
    return 0.0625f * (c0 + 2 * c1 + c2 + 2 * c3 + 4 * c4 + 2 * c5 + c6 + 2 * c7 + c8) * strength;
}