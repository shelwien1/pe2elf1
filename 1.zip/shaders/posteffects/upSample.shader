Texture2D<float4> _texture : register(t0);
SamplerState defaultSampler : register(s0);

cbuffer data : register(b0) 
{
    float2 inverseResolution;
    float streakLength;
    float radius;
    float strength;
}

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float4 mainPS(PS_INPUT p) : SV_Target
{
    float2 offset = float2(streakLength * inverseResolution.x, inverseResolution.y) * radius;

    float4 c0 = _texture.Sample(LinearSampler, defaultSampler + float2(-1, -1) * offset);
    float4 c1 = _texture.Sample(LinearSampler, defaultSampler + float2(0, -1) * offset);
    float4 c2 = _texture.Sample(LinearSampler, defaultSampler + float2(1, -1) * offset);
    float4 c3 = _texture.Sample(LinearSampler, defaultSampler + float2(-1, 0) * offset);
    float4 c4 = _texture.Sample(LinearSampler, defaultSampler);
    float4 c5 = _texture.Sample(LinearSampler, defaultSampler + float2(1, 0) * offset);
    float4 c6 = _texture.Sample(LinearSampler, defaultSampler + float2(-1,1) * offset);
    float4 c7 = _texture.Sample(LinearSampler, defaultSampler + float2(0, 1) * offset);
    float4 c8 = _texture.Sample(LinearSampler, defaultSampler + float2(1, 1) * offset);

    //Tentfilter  0.0625f    
    return 0.0625f * (c0 + 2 * c1 + c2 + 2 * c3 + 4 * c4 + 2 * c5 + c6 + 2 * c7 + c8) * strength;
}