#include <common/shaderVariables.hlsl>
#include <common/noise.hlsl>

Texture2D<float4> _texture : register(t0);
SamplerState defaultSampler : register(s0);

Texture2D<float4> _noiseTexture : register(t1);
SamplerState noiseSampler : register(s1);

CBUFFER_START(Data, 0)
    float2 textureSize;
    float scanLineSpeed;
    float scanLineStrength;
    float noiseStrength;
CBUFFER_END

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float4 mainPS(PS_INPUT p) : SV_Target
{
    float4 color = _texture.Sample(defaultSampler, p.uv);
    float noise = q1DNoiseSample(0.005,0.005, _noiseTexture, noiseSampler);
    color = cSignalNoise (color, noise * noiseStrength, p.uv, _noiseTexture, noiseSampler) * color.a;
    color = color * lerp(1.0,saturate(scanLine (p.uv + float2(0, -frac(time * scanLineSpeed)), textureSize.y / 3 )), scanLineStrength);
    return color;
}