Texture2D<float4> _texture : register(t0);
Texture2D<float4> _lut : register(t1);
SamplerState defaultSampler : register(s0);

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

static const float2 lut_size = float2(256.0, 16.0);

float4 mainPS(PS_INPUT p) : SV_Target
{
    float4 colorIn = saturate(_texture.Sample(defaultSampler, p.uv));

    //return colorIn;

    float2 lutSize = 1.0 / lut_size;
    float4 lutUV;

    colorIn = saturate(colorIn) * ( lut_size.y - 1.0);
    lutUV.w  = floor(colorIn.b);
    lutUV.xy = (colorIn.rg + 0.5) * lutSize;
    lutUV.x += lutUV.w * lutSize.y;
    lutUV.z  = lutUV.x + lutSize.y;

    float3 color = lerp(_lut.Sample(defaultSampler, lutUV.xy).rgb, _lut.Sample(defaultSampler, lutUV.zy).rgb, colorIn.b - lutUV.w);

    return float4(color, colorIn.a);

}