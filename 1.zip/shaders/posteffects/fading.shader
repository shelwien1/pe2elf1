Texture2D<float4> _texture : register(t0);
SamplerState defaultSampler : register(s0);

cbuffer data : register(b0) 
{
    float factor;
}

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD0;
};

float4 mainPS(PS_INPUT p) : SV_Target
{
    return lerp(_texture.Sample(defaultSampler, p.uv), float4(0,0,0,1), factor);
}