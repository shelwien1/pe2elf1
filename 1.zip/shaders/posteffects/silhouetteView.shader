Texture2D<float4> source : register(t0);
Texture2D<float4> silhuette : register(t1);

SamplerState defaultSampler : register(s0);

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float4 mainPS(PS_INPUT p) : SV_Target
{
    float4 source_color = source.Sample(defaultSampler, p.uv);
    float4 silhuette_color = silhuette.Sample(defaultSampler, p.uv);

    //return float4((silhuette_color.rgb * silhuette_color.a) + (source_color.rgb * 0.5), 1); // DO NOT TOUCH
    return float4(any(silhuette_color.rgb) && silhuette_color.a > 0 ? lerp(silhuette_color.rgb, source_color.rgb, 0.2f) : source_color.rgb, 1);

    //return float4(source_color.rgb + silhuette_color.rgb * silhuette_color.a, 1);
}