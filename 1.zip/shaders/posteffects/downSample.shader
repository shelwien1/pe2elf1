Texture2D<float4> _texture : register(t0);
SamplerState defaultSampler : register(s0);

cbuffer data : register(b0) 
{
    float2 inverseResolution;
    float streakLength;
}

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

//Just an average of 4 values.
float4 box4(float4 p0, float4 p1, float4 p2, float4 p3)
{
	return (p0 + p1 + p2 + p3) * 0.25f;
}

float4 mainPS(PS_INPUT p) : SV_Target
{
    float2 offset = float2(streakLength * inverseResolution.x, inverseResolution.y);
        
    float4 c0  = _texture.Sample(defaultSampler, p.uv + float2(-2, -2) * offset);
    float4 c1  = _texture.Sample(defaultSampler, p.uv + float2( 0, -2) * offset);
    float4 c2  = _texture.Sample(defaultSampler, p.uv + float2( 2, -2) * offset);
    float4 c3  = _texture.Sample(defaultSampler, p.uv + float2(-1, -1) * offset);
    float4 c4  = _texture.Sample(defaultSampler, p.uv + float2( 1, -1) * offset);
    float4 c5  = _texture.Sample(defaultSampler, p.uv + float2(-2,  0) * offset);
    float4 c6  = _texture.Sample(defaultSampler, p.uv);
    float4 c7  = _texture.Sample(defaultSampler, p.uv + float2( 2, 0) * offset);
    float4 c8  = _texture.Sample(defaultSampler, p.uv + float2(-1, 1) * offset);
    float4 c9  = _texture.Sample(defaultSampler, p.uv + float2( 1, 1) * offset);
    float4 c10 = _texture.Sample(defaultSampler, p.uv + float2(-2, 2) * offset);
    float4 c11 = _texture.Sample(defaultSampler, p.uv + float2( 0, 2) * offset);
    float4 c12 = _texture.Sample(defaultSampler, p.uv + float2( 2, 2) * offset);

    return box4(c0, c1, c5, c6) * 0.125f +
        box4(c1, c2, c6, c7) * 0.125f +
        box4(c5, c6, c10, c11) * 0.125f +
        box4(c6, c7, c11, c12) * 0.125f +
        box4(c3, c4, c8, c9) * 0.5f;
}