Texture2D<float4> _texture : register(t0);
SamplerState defaultSampler : register(s0);

struct PS_INPUT
{
    float4 pos: SV_Position;
    float2 uv: TEXCOORD;
};

float4 mainPS(PS_INPUT p) : SV_Target
{
    return _texture.Sample(defaultSampler, p.uv);
}