#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"


Texture2D<float4> _mainTexture : register(t0);

struct v2v
{
    float4 position : POSITION;
#ifdef _USE_UV
    float2 uv : TEXCOORD0;
#endif
#ifdef _VERTEX_COLOR
    float4 color: COLOR;
#endif        
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
};

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.pixelPosition = mul(mul(v.position, matrix_ObjectToWorld), matrixViewProj);
#ifdef _USE_UV
    o.uv = v.uv;
#endif
#ifdef _VERTEX_COLOR
    o.color = saturate(v.color);
#else
    o.color = float4(1,1,1,1);
#endif
    
    return o;
}

float4 mainPS(v2p p) : SV_TARGET
{
    float4 color = float4(1,1,1,1);
#ifdef _USE_UV
    color *= _mainTexture.Sample(defaultSampler, p.uv);
#endif
#ifdef _VERTEX_COLOR
    color *= p.color;
#endif
    return color;
}
