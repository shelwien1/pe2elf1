#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"


Texture2D<float4> _mainTexture : register(t0);

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
};

CBUFFER_START(Data, 0)
    float emissionPower;
CBUFFER_END

v2p mainVS(v2v v)
{
    INITIALIZE_OUTPUT(v2p, o);
    o.uv = v.uv;
    o.pixelPosition = mul(mul(float4(v.position.xyz,1), matrix_ObjectToWorld), matrixViewProj);
    
    return o;
}

struct PS_OUTPUT
{
    float4 color:   SV_Target0;
    float4 emission: SV_Target1;
};

PS_OUTPUT mainPS(v2p p) : SV_TARGET
{
    INITIALIZE_OUTPUT(PS_OUTPUT, o)
    o.color = _mainTexture.Sample(defaultSampler, p.uv);
    o.emission = o.color * emissionPower;
    return o;
}
