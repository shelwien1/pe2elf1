#ifndef __SHADER_VARIABLES_INCLUDED__
#define __SHADER_VARIABLES_INCLUDED__

#define INITIALIZE_OUTPUT(type,name) type name; name = (type)0; 

#define CBUFFER_START(name, reg) cbuffer name : register(b##reg) {
#define CBUFFER_END }

CBUFFER_START(DataPerFrame, 1)
    float4x4 matrixProj;
    float4x4 matrixView;
    float4x4 matrixInvView;
    float4x4 matrixViewProj;
    float4x4 matrixViewProj2D;

    float3 worldSpaceCameraPos;
    float4x4 fixRotationMatrix;

    float4 clipPlane;
    float terrainSize;
    float terrainHeight;
    float cameraNearPlane;
    float cameraFarPlane;
    float time;
CBUFFER_END

CBUFFER_START(DataPerDraw, 2)
    float4x4 matrix_ObjectToWorld;
    float4x4 matrix_WorldToObject;
    float4 silhouetteColor;
    float4 damageColor;
    float2 damageColorAlpha;
    float damageColorPulseFrequency;
    uint firstSplitIndex;
    uint lastSplitIndex;    
CBUFFER_END

CBUFFER_START(Lighting, 3)
    float exposure;
    float shadowBias;
    float addFactor;
    //float padding2;
    float4 ambientColor;
    float4x4 ambientRotationMatrix;

    float3 directLightDir;
    float shadowOpacity;
    float3 directLightColor;
    
    float2 fogMin;
    float2 fogMax;
    
    float4 fogColor;

    float fogBorder;
    float fogEnd;
    float fogStart;
    float padding;
    
    float topFog;
    float topFogBorder;
    float bottomFog;
    float bottomFogBorder;

    float topOpacity;
    float bottomOpacity;
    float padding3;
    float padding4;
    
    float4 fogTopVerticalColor;
    float4 fogBottomVerticalColor;
    // float4 shAr;
    // float4 shAg;
    // float4 shAb;
    // float4 shBr;
    // float4 shBg;
    // float4 shBb;
    // float4 shC;
CBUFFER_END

CBUFFER_START(SkinMatrices, 5)
    float4x4 skinMatrix[96];
CBUFFER_END

struct DamageOBB
{
    float4 pos;
    float4 sizeX;
    float4 sizeY;
    float4 sizeZ;
    float4 color;
    float4 colorAlpha;
};

CBUFFER_START(DamageData, 7)
    DamageOBB obbs[10];
    int count;
CBUFFER_END

#endif //__SHADER_VARIABLES_INCLUDED__