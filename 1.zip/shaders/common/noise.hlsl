#ifndef __NOISE_INCLUDED__
#define __NOISE_INCLUDED__
#define M_PI (3.1415926535897932384626433832795)

float scanLine (float2 uv, float n) 
{
	return abs (cos (uv.y*M_PI*n)) ; 
}

float4 v2DNoiseSample (float2 gPos, const Texture2D<float4> tex, SamplerState samplerState) 
{
	float2 nPos = float2(fmod(gPos.x+time*9.66,1.0), fmod(gPos.y+time*7.77,1.0));		
	return tex.Sample(samplerState, nPos);
}

float4 v1DNoiseSample (float idx, float s, Texture2D<float4> tex, SamplerState samplerState) 
{	
	return tex.Sample(samplerState, float2(fmod(idx, 1.0), fmod(time*s, 1.0)));
}

float q2DNoiseSample (float2 gPos, Texture2D<float4> tex, SamplerState samplerState) 
{
 	float4 nPnt = v2DNoiseSample (gPos, tex, samplerState);
	return nPnt.x;
}

float q1DNoiseSample (float idx, float s, Texture2D<float4> tex, SamplerState samplerState)
{
	float4 nPnt = v1DNoiseSample (idx, s, tex, samplerState);
	return nPnt.x;
}

float4 cSignalNoise (float4 c,float q, float2 gPos, Texture2D<float4> tex, SamplerState samplerState) 
{
	return c*(1.0 - q) + q*q2DNoiseSample(gPos, tex, samplerState);
}

#endif // __NOISE_INCLUDED__