#ifndef __STANDARD_CORE_INCLUDED__
#define __STANDARD_CORE_INCLUDED__

#include "baseCG.hlsl"
#include "light.hlsl"
Texture2D<float4> _albedoTexture : register(t0);
Texture2D<float2> _normalTexture : register(t1);
Texture2D<float4> _roughTexture : register(t2);
Texture2D<float4> _emissionTexture : register(t3);
Texture2D<float> _heightMap : register(t10);
Texture2D<float2> _normalMap : register(t11);
#endif //__STANDARD_CORE_INCLUDED__