#ifndef __SHADOW_MAPPING_INCLIDED__
#define __SHADOW_MAPPING_INCLIDED__

Texture2DArray<float4> _shadowTexture : register(t4);
SamplerComparisonState shadowSampler : register(s10);

CBUFFER_START(Shadows, 4)
    float4x4 matrix_shadowVP[6];
    float4 splitPlane;
    float shadowMapSize;
    float invShadowMapSize;
    int numSplits;
    float shadowMaxDistance;
    float shadowStartFadeDistance;
CBUFFER_END

#define DIRECTIONAL
#ifndef CASCADES
    #define CASCADES 4
#endif
#define PCF_SAMPLES 4
#define PCF_DIM float(PCF_SAMPLES) / 2.0f

float2 project(float4 value)
{
    return (value.xy / value.w);// * float2(0.5f, -0.5f) + 0.5f;
}

float DepthTest_Directional(float slice, float2 tex_coords, float compare)
{
    return _shadowTexture.SampleCmpLevelZero(shadowSampler, float3(tex_coords, slice), compare).r;
    // float depthValue = _shadowTexture.SampleCmpLevelZero(shadowSampler, float3(tex_coords, slice), compare).r;
    // if(compare < depthValue)
    //     return 1.0f;
    // return 0;
    
    //return _shadowTexture.SampleCmpLevelZero(shadowSampler, float3(tex_coords, slice), compare).r;
}

float Technique_PCF_2d(int cascade, float texel, float2 tex_coords, float compare)
{
    float amountLit = 0.0f;
    float count = 0.0f;
	
	[unroll]
    for (float y = -PCF_DIM; y <= PCF_DIM; ++y)
    {
		[unroll]
        for (float x = -PCF_DIM; x <= PCF_DIM; ++x)
        {
            float2 offset = float2(x, y) * texel;
			
#ifdef DIRECTIONAL
			amountLit 	+= DepthTest_Directional(cascade, tex_coords + offset, compare);
#elif SPOT
			amountLit 	+= DepthTest_Spot(tex_coords + offset, compare);
#endif
			
            count++;
        }
    }
    return pow(amountLit /= count, 2.2);
    //return amountLit /= count;
}

float ShadowMapping_Directional(in float distance, in int cascade, in float4 positionCS, in float texel, in float bias)
{
	// If the cascade is not covering this pixel, don't sample anything
    [flatten]
    if (positionCS.x < -1.0f || positionCS.x > 1.0f ||
		positionCS.y < -1.0f || positionCS.y > 1.0f ||
		positionCS.z < 0.0f || positionCS.z > 1.0f)
        return 1.0f;
    
    float2 tex_coord = project(positionCS);
    float compare_depth = positionCS.z / positionCS.w - bias;
    //float shadow = _shadowTexture.SampleCmpLevelZero(shadowSampler, float3(tex_coord, cascade), compare_depth).r;
    float shadow = Technique_PCF_2d(cascade, texel, tex_coord, compare_depth);

    return lerp(shadow, 1, saturate((distance - shadowStartFadeDistance) / (shadowMaxDistance - shadowStartFadeDistance)));

}

float shadowMapping2(float4 viewSpacePos, float4 positionCS[4])
{
    float lightingFactor = 1.0;
    float distance = -viewSpacePos.z;
    float texel = invShadowMapSize;
    for(int i=0; i<numSplits; i++)
    {
        if(distance < splitPlane[i])
        {
            return ShadowMapping_Directional(distance, i, positionCS[i], texel, shadowBias);
            break;
        }
    }
    return ShadowMapping_Directional(distance, numSplits-1, positionCS[numSplits-1], texel, shadowBias);;
}

static float3 debugCascadeColors[4] = {
    float3(1,0,0), 
    float3(0,1,0), 
    float3(0,0,1),
    float3(1,0,1)
};


float3 debugCascadeColor2(float4 viewSpacePos, float4 positionCS[4])
{
    float3 color = float3(1,1,1);
    float distance = -viewSpacePos.z;
    for(int i=0; i<numSplits; i++)
    {
        if(distance < splitPlane[i])
        {
            color = debugCascadeColors[i];
            break;
        }
    }
    return color;
}
float shadowMapping(float4 positonCS[4], float ndotl)
{
    //float bias = max(0.001 * (1 - ndotl),  0.0008);//0.003 * tan(acos(ndotl));
    //bias = 0.0001 * tan(acos(ndotl));
    //bias = clamp(bias, 0, 0.01);
    //float bias = 0.0003f;
    float texel = invShadowMapSize;

    float3 tex_coords[3];
    tex_coords[0] = positonCS[0].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;
    tex_coords[1] = positonCS[1].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;
    tex_coords[2] = positonCS[2].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;

    int cascade = -1;
	[unroll]
    for (int i = 2; i >= 0; i--)
    {
        cascade = any(tex_coords[i] - saturate(tex_coords[i])) ? cascade : i;
    }

    [branch]
    if (cascade != -1)
    {
        float3 cascadeBlend = abs(tex_coords[cascade] * 2 - 1);
        int2 cascades = int2(cascade, cascade + 1);
        float shadows[2] = { 1.0f, 1.0f };

        // Sample the main cascade	
        shadows[0] = ShadowMapping_Directional(0,cascades[0], positonCS[cascades[0]], texel, shadowBias);

        [branch]
        if (cascades[1] <= 2)
        {
            shadows[1] = ShadowMapping_Directional(0,cascades[1], positonCS[cascades[1]], texel, shadowBias);
        }

        // Blend cascades		
        return shadows[0];
        //return lerp(shadows[0], shadows[1], pow(max(cascadeBlend.x, max(cascadeBlend.y, cascadeBlend.z)), 4));
    }
    else
    {
        return 1.0f;
    }
}

float3 debugCascadeColor(float4 positonCS[3])
{
    float bias = 0.001;
    float texel = invShadowMapSize;

    float3 tex_coords[3];
    tex_coords[0] = positonCS[0].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;
    tex_coords[1] = positonCS[1].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;
    tex_coords[2] = positonCS[2].xyz * float3(0.5f, -0.5f, 0.5f) + 0.5f;

    int cascade = -1;
	[unroll]
    for (int i = 2; i >= 0; i--)
    {
        cascade = any(tex_coords[i] - saturate(tex_coords[i])) ? cascade : i;
    }


 [branch]
    if (cascade != -1)
    {
        float3 cascadeBlend = abs(tex_coords[cascade] * 2 - 1);
        int2 cascades = int2(cascade, cascade + 1);
        float3 resultColors[2] = { float3(1,1,1), float3(1,1,1) };

        // Sample the main cascade	
        resultColors[0] = debugCascadeColors[cascades[0]];

        [branch]
        if (cascades[1] <= 2)
        {
            resultColors[1] = debugCascadeColors[cascades[1]];
        }

        // Blend cascades		
        return resultColors[0];
        //return lerp(resultColors[0], resultColors[1], pow(max(cascadeBlend.x, max(cascadeBlend.y, cascadeBlend.z)), 4));
    }
    
    return float3(1,1,1);
}

#endif //__SHADOW_MAPPING_INCLIDED__