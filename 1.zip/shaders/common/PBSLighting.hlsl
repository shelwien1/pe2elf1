struct SurfaceStandard
{
    float3 Albedo;
    float3 Normal;
    float4 Emission;
    float Metallic;     // 0=non-metal, 1=metal
    float Roughness;    // 1=rough, 0=smooth
    float Occlusion;    // occlusion (default 1)
    float Alpha;        // alpha for transparencies
};
