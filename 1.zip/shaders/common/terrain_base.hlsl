#ifndef __TERRAIN_BASE_INCLIDED__
#define __TERRAIN_BASE_INCLIDED__

#include "baseCG.hlsl"

#if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES) && !defined(_MAX12TEXTURES) && !defined(_MAX16TEXTURES) && !defined(_MAX20TEXTURES) && !defined(_MAX24TEXTURES) && !defined(_MAX28TEXTURES) && !defined(_MAX32TEXTURES)
#define _MAX4TEXTURES
#endif
#if _MAX8TEXTURES
    #define TEXCOUNT 8
#elif _MAX12TEXTURES
    #define TEXCOUNT 12
#elif _MAX16TEXTURES
    #define TEXCOUNT 16
#elif _MAX20TEXTURES
    #define TEXCOUNT 20
#elif _MAX24TEXTURES
    #define TEXCOUNT 24
#elif _MAX28TEXTURES
    #define TEXCOUNT 28
#elif _MAX32TEXTURES
    #define TEXCOUNT 32
#else
    #define TEXCOUNT 4
#endif

SamplerState splatMapSampler : register(s2);

Texture2DArray<half4> _albedoTexture : register(t0);
Texture2DArray<float2> _normalTexture : register(t1);
Texture2DArray<half4> _roughTexture : register(t2);

Texture2D<float4> _splatMap0 : register(t12);
#if !defined(_MAX4TEXTURES)
Texture2D<float4> _splatMap1 : register(t13);
#endif
#if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES)
Texture2D<float4> _splatMap2 : register(t14);
#endif
#if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES) && !defined(_MAX12TEXTURES)
Texture2D<float4> _splatMap3 : register(t15);
#endif
#if defined(_MAX20TEXTURES) || defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
Texture2D<float4> _splatMap4 : register(t16);
#endif
#if defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
Texture2D<float4> _splatMap5 : register(t17);
#endif
#if defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
Texture2D<float4> _splatMap6 : register(t18);
#endif
#if defined(_MAX32TEXTURES)
Texture2D<float4> _splatMap7 : register(t19);
#endif

struct SplatLayer
{
    half3 Albedo;
    float3 Normal;
    half Metallic;
    half Roughness;
    half Occlusion;
    half Height;
    half3 Emission;
    half Alpha;
};

struct TerrainConfig
{
    float2 uv;
    float4 uv0;
    float4 uv1;
    float4 uv2;
    float4 uv3;

    half4 cluster0;
    half4 cluster1;
    half4 cluster2;
    half4 cluster3;

    float3 normal;

    float3x3 TBN;

};

struct RawSamples
{
    half4 albedo0;
    half4 albedo1;
    half4 albedo2;
    half4 albedo3;

    float3 normal0;
    float3 normal1;
    float3 normal2;
    float3 normal3;

    half4 metallic;
    half4 roughness;
    half4 occlusion;
};

void SampleAlbedo(Texture2DArray<half4> inputTexture, inout TerrainConfig config, inout RawSamples s)
{
    s.albedo0 = (half4)texSample(inputTexture, defaultSampler, config.uv0.xyz);
    s.albedo1 = (half4)texSample(inputTexture, defaultSampler, config.uv1.xyz);
    s.albedo2 = (half4)texSample(inputTexture, defaultSampler, config.uv2.xyz);
    s.albedo3 = (half4)texSample(inputTexture, defaultSampler, config.uv3.xyz);
}

void SampleNormal(Texture2DArray<float2> inputTexture, inout TerrainConfig config, inout RawSamples s)
{
    float3x3 tbn0 = makeTBN(config.normal, float4(cos(config.uv0.w), sin(config.uv0.w), 0, 1));
    float3x3 tbn1 = makeTBN(config.normal, float4(cos(config.uv1.w), sin(config.uv1.w), 0, 1));
    float3x3 tbn2 = makeTBN(config.normal, float4(cos(config.uv2.w), sin(config.uv2.w), 0, 1));
    float3x3 tbn3 = makeTBN(config.normal, float4(cos(config.uv3.w), sin(config.uv3.w), 0, 1));
   
    s.normal0 = normalize(mul(unpackNormal(texSample(inputTexture, defaultSampler, config.uv0.xyz)), tbn0));
    s.normal1 = normalize(mul(unpackNormal(texSample(inputTexture, defaultSampler, config.uv1.xyz)), tbn1));
    s.normal2 = normalize(mul(unpackNormal(texSample(inputTexture, defaultSampler, config.uv2.xyz)), tbn2));
    s.normal3 = normalize(mul(unpackNormal(texSample(inputTexture, defaultSampler, config.uv3.xyz)), tbn3));
}

void SampleRoughnessMetallicOcclusion(Texture2DArray<half4> inputTexture, inout TerrainConfig config, inout RawSamples s)
{
    half4 data0 = (half4)texSample(inputTexture, defaultSampler, config.uv0.xyz);
    half4 data1 = (half4)texSample(inputTexture, defaultSampler, config.uv1.xyz);
    half4 data2 = (half4)texSample(inputTexture, defaultSampler, config.uv2.xyz);
    half4 data3 = (half4)texSample(inputTexture, defaultSampler, config.uv3.xyz);

    s.metallic.x = data0[0];
    s.metallic.y = data1[0];
    s.metallic.z = data2[0];
    s.metallic.w = data3[0];

    s.roughness[0] = data0[1];
    s.roughness[1] = data1[1];
    s.roughness[2] = data2[1];
    s.roughness[3] = data3[1];

    s.occlusion[0] = data0[2];
    s.occlusion[1] = data1[2];
    s.occlusion[2] = data2[2];
    s.occlusion[3] = data3[2];
}

CBUFFER_START(LayersData, 6)
    float4 offsetAngle[32];
CBUFFER_END

float4 applyLayerData(float3 uv)
{
    float angle = offsetAngle[(uint)uv.z].z;

    float cosA = cos(angle);
    float sinA = sin(angle);

    float x = uv.x * cosA - uv.y * sinA - offsetAngle[(uint)uv.z].x;
    float y = uv.x * sinA + uv.y * cosA - offsetAngle[(uint)uv.z].y;

    return float4(x, y, uv.z, angle);
}

void TerrainSetup(out half4 weights, float2 uv, out TerrainConfig config, half4 w0, half4 w1, half4 w2, half4 w3, half4 w4, half4 w5, half4 w6, half4 w7, float3 worldPos)
{
    config = (TerrainConfig)0;
    half4 indexes = 0;

    config.uv = uv;
    float2 scaledUV = uv;
    
#ifdef _MAX4TEXTURES
    weights = w0;
    config.uv0 = applyLayerData(float3(scaledUV, 0));
    config.uv1 = applyLayerData(float3(scaledUV, 1));
    config.uv2 = applyLayerData(float3(scaledUV, 2));
    config.uv3 = applyLayerData(float3(scaledUV, 3));
    return;
#endif

    half splats[TEXCOUNT];

    splats[0] = w0.x;
    splats[1] = w0.y;
    splats[2] = w0.z;
    splats[3] = w0.w;
    #if !defined(_MAX4TEXTURES)
    splats[4] = w1.x;
    splats[5] = w1.y;
    splats[6] = w1.z;
    splats[7] = w1.w;
    #endif
    #if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES)
    splats[8] = w2.x;
    splats[9] = w2.y;
    splats[10] = w2.z;
    splats[11] = w2.w;
    #endif
    #if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES) && !defined(_MAX12TEXTURES)
    splats[12] = w3.x;
    splats[13] = w3.y;
    splats[14] = w3.z;
    splats[15] = w3.w;
    #endif
    #if defined(_MAX20TEXTURES) || defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    splats[16] = w4.x;
    splats[17] = w4.y;
    splats[18] = w4.z;
    splats[19] = w4.w;
    #endif
    #if defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    splats[20] = w5.x;
    splats[21] = w5.y;
    splats[22] = w5.z;
    splats[23] = w5.w;
    #endif
    #if defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    splats[24] = w6.x;
    splats[25] = w6.y;
    splats[26] = w6.z;
    splats[27] = w6.w;
    #endif
    #if defined(_MAX32TEXTURES)
    splats[28] = w7.x;
    splats[29] = w7.y;
    splats[30] = w7.z;
    splats[31] = w7.w;
    #endif
    
    weights[0] = 0;
    weights[1] = 0;
    weights[2] = 0;
    weights[3] = 0;
    indexes[0] = 0;
    indexes[1] = 0;
    indexes[2] = 0;
    indexes[3] = 0;

    int i = 0;
    for (i = 0; i < TEXCOUNT; ++i)
    {
        half w = splats[i];
        if (w >= weights[0])
        {
            weights[3] = weights[2];
            indexes[3] = indexes[2];
            weights[2] = weights[1];
            indexes[2] = indexes[1];
            weights[1] = weights[0];
            indexes[1] = indexes[0];
            weights[0] = w;
            indexes[0] = (half)i;
        }
        else if (w >= weights[1])
        {
            weights[3] = weights[2];
            indexes[3] = indexes[2];
            weights[2] = weights[1];
            indexes[2] = indexes[1];
            weights[1] = w;
            indexes[1] = (half)i;
        }
        else if (w >= weights[2])
        {
            weights[3] = weights[2];
            indexes[3] = indexes[2];
            weights[2] = w;
            indexes[2] = (half)i;
        }
        else if (w >= weights[3])
        {
            weights[3] = w;
            indexes[3] = (half)i;
        }
    }

    config.uv0 = applyLayerData(float3(scaledUV, indexes.x));
    config.uv1 = applyLayerData(float3(scaledUV, indexes.y));
    config.uv2 = applyLayerData(float3(scaledUV, indexes.z));
    config.uv3 = applyLayerData(float3(scaledUV, indexes.w));
}

inline half BlendWeights(half s1, half s2, half s3, half s4, half4 w)      { return s1 * w.x + s2 * w.y + s3 * w.z + s4 * w.w; }
inline half2 BlendWeights(half2 s1, half2 s2, half2 s3, half2 s4, half4 w) { return s1 * w.x + s2 * w.y + s3 * w.z + s4 * w.w; }
inline half3 BlendWeights(half3 s1, half3 s2, half3 s3, half3 s4, half4 w) { return s1 * w.x + s2 * w.y + s3 * w.z + s4 * w.w; }
inline half4 BlendWeights(half4 s1, half4 s2, half4 s3, half4 s4, half4 w) { return s1 * w.x + s2 * w.y + s3 * w.z + s4 * w.w; }
inline float3 BlendWeights(float3 s1, float3 s2, float3 s3, float3 s4, float4 w) { return s1 * w.x + s2 * w.y + s3 * w.z + s4 * w.w; }

half4 ComputeWeights(half4 iWeights, half h0, half h1, half h2, half h3, half contrast)
{
        // compute weight with height map
        half4 weights = half4(iWeights.x * max(h0,0.001), iWeights.y * max(h1,0.001), iWeights.z * max(h2,0.001), iWeights.w * max(h3,0.001));
        
        // Contrast weights
        half maxWeight = max(max(weights.x, max(weights.y, weights.z)), weights.w);
        half transition = max(contrast * maxWeight, 0.0001);
        half threshold = maxWeight - transition;
        half scale = 1.0 / transition;
        weights = (half4)saturate((weights - threshold) * scale);
        //weights = saturate(weights);
        // Normalize weights.
        half weightScale = 1.0 / (weights.x + weights.y + weights.z + weights.w);
        weights *= weightScale;
        return weights;
}

SplatLayer TerrainSample(half4 weights, inout TerrainConfig config)
{
    SplatLayer o = (SplatLayer)0;
    RawSamples samples = (RawSamples)0;

    SampleAlbedo(_albedoTexture, config, samples);

    half4 heightWeights = ComputeWeights(weights, samples.albedo0.a, samples.albedo1.a, samples.albedo2.a, samples.albedo3.a, 0.3);
    half4 albedo = BlendWeights(samples.albedo0, samples.albedo1, samples.albedo2, samples.albedo3, heightWeights);

    SampleNormal(_normalTexture, config, samples);
    float3 normal = BlendWeights(samples.normal0, samples.normal1, samples.normal2, samples.normal3, heightWeights);

    SampleRoughnessMetallicOcclusion(_roughTexture, config, samples);
    half metallic = BlendWeights(samples.metallic[0], samples.metallic[1], samples.metallic[2], samples.metallic[3], heightWeights);
    half roughness = BlendWeights(samples.roughness[0], samples.roughness[1], samples.roughness[2], samples.roughness[3], heightWeights);
    half occlusion = BlendWeights(samples.occlusion[0], samples.occlusion[1], samples.occlusion[2], samples.occlusion[3], heightWeights);

    o.Albedo = albedo.rgb;
    o.Normal = normal;
    o.Metallic = metallic;
    o.Roughness = roughness;
    o.Occlusion = occlusion;
    o.Height = albedo.a;

    return o;
}

SplatLayer GetSplatLayer(float2 splat_uv, float2 uv, float3 normal)
{
    half4 w0 = (half4)_splatMap0.SampleLevel(splatMapSampler, splat_uv, 0);
    half4 w1 = 0; half4 w2 = 0; half4 w3 = 0; half4 w4 = 0; half4 w5 = 0; half4 w6 = 0; half4 w7 = 0;

    #if !defined(_MAX4TEXTURES)
    w1 = (half4)_splatMap1.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES)
    w2 = (half4)_splatMap2.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if !defined(_MAX4TEXTURES) && !defined(_MAX8TEXTURES) && !defined(_MAX12TEXTURES)
    w3 = (half4)_splatMap3.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if defined(_MAX20TEXTURES) || defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    w4 = (half4)_splatMap4.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if defined(_MAX24TEXTURES) || defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    w5 = (half4)_splatMap5.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if defined(_MAX28TEXTURES) || defined(_MAX32TEXTURES)
    w6 = (half4)_splatMap6.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif
    #if defined(_MAX32TEXTURES)
    w7 = (half4)_splatMap7.SampleLevel(splatMapSampler, splat_uv, 0);
    #endif

    half4 weights;
    TerrainConfig config = (TerrainConfig)0;
    TerrainSetup(weights, uv, config, w0, w1, w2, w3, w4, w5, w6, w7, float3(0,0,0));
    config.normal = normal;
    
    SplatLayer l = TerrainSample(weights, config);
    return l;
}

#endif //__TERRAIN_BASE_INCLIDED__