#ifndef __STANDARD_INPUT_INCLUDED__
#define __STANDARD_INPUT_INCLUDED__

#include "baseCG.hlsl"

CBUFFER_START(Constants, 0)
    float4 albedoColor;
    float3 metal_roughness_cutoff;
    float4 emissionColor;
CBUFFER_END

#define _metallic metal_roughness_cutoff.x
#define _roughness metal_roughness_cutoff.y
#define _cutoff metal_roughness_cutoff.z


half3 Albedo(float2 uv)
{
#ifndef _ALBEDO_MAP    
    return albedoColor.rgb;
#else
    half3 albedo = albedoColor.rgb * _mainTexture.Sample(defaultSampler, uv).rgb;
    return albedo;
#endif
}

half Alpha(float2 uv)
{
#ifndef _ALBEDO_MAP    
    return albedoColor.a;
#else
    return _mainTexture.Sample(defaultSampler, uv).a * albedoColor.a;
#endif
}

half Occlusion(float2 uv)
{
    return 1;
}

half2 MetallicRough(float2 uv)
{
    half2 mr;
#ifdef _METALLIC_MAP
    mr.r = _metallicMap.Sample(defaultSampler, uv).r;
#else
    mr.r = _metallic;
#endif

#ifdef _ROUGH_MAP
    mr.g = _roughnessMap.Sample(defaultSampler, uv).r;
#else
    mr.g = _roughness;
#endif
    return mr;
}

half3 Emission(float2 uv)
{
#ifndef _EMISSION
    return 0;
#else
    return _emissionMap.Sample(defaultSampler, uv).rgb * emissionColor.rgb;
#endif
}

#endif //__STANDARD_INPUT_INCLUDED__