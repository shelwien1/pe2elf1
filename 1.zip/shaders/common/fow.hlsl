#ifndef __FOW_INCLUDED__
#define __FOW_INCLUDED__

#include "baseCG.hlsl"

Texture2D<float4> _fogOfWar : register(t32);
SamplerState fogOfWarMapSampler : register(s4);

float3 applyFogOwWar(float3 color, float3 fogColor, float fow)
{
    float3 LuminanceConv = { 0.2125f, 0.7154f, 0.0721f };
    float3 monoColor = lerp(color, dot(color, LuminanceConv), 0.8) * 0.4f;
    color = lerp(monoColor, color, fow);
   return color;
 
}

#endif //__FOW_INCLUDED__