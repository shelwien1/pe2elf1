#ifndef __TONE_MAPPING_INCLUDED__
#define __TONE_MAPPING_INCLUDED__

#include "shaderVariables.hlsl"

static const float gamma = 2.2;
static const float pureWhite = 1.0;

float CalcLuminance(float3 color)
{
    return dot(color, float3(0.2126f, 0.7152f, 0.0722f));
}

float3 LinearTosRGB(in float3 color)
{
    float3 x = color * 12.92f;
    float3 y = 1.055f * pow(saturate(color), 1.0f / 2.4f) - 0.055f;

    float3 clr = color;
    clr.r = color.r < 0.0031308f ? x.r : y.r;
    clr.g = color.g < 0.0031308f ? x.g : y.g;
    clr.b = color.b < 0.0031308f ? x.b : y.b;

    return clr;
}

float3 Uncharted2Tonemap(float3 x)
{
    float A = 0.15;
	float B = 0.50;
	float C = 0.10;
	float D = 0.20;
	float E = 0.02;
	float F = 0.30;

    return ((x*(A*x+C*B)+D*E)/(x*(A*x+B)+D*F))-E/F;
}

float3 SimpleReinhard(float3 color)
{
    float3 mapped = color / (color + 1.0);
    // гамма-коррекция
    mapped = pow(mapped, 1.0 / gamma);
    return mapped;
}

// Applies the filmic curve from John Hable's presentation
float3 ToneMapFilmicALU(in float3 color)
{
    color = max(0, color - 0.004f);
    color = (color * (6.2f * color + 0.5f)) / (color * (6.2f * color + 1.7f)+ 0.06f);
    return color;
}

float3 Reinhard(float3 color)
{
	// Reinhard tonemapping operator.
	// see: "Photographic Tone Reproduction for Digital Images", eq. 4
    float luminance = dot(color, float3(0.2126, 0.7152, 0.0722));
    float mappedLuminance = (luminance * (1.0 + luminance / (pureWhite * pureWhite))) / (1.0 + luminance);

	// Scale color by ratio of average luminances.
    float3 mappedColor = (mappedLuminance / luminance) * color;
    mappedColor = pow(abs(mappedColor), 1.0 / gamma);
    
    return mappedColor;
}


float3 ToneMap(in float3 color)
{
    float3 output;
    color = color.rgb * exposure.r;

    //output = Uncharted2Tonemap(color);
    output = LinearTosRGB(color);
    //output = Reinhard(color);
    //output = SimpleReinhard(color);
    //output = ToneMapFilmicALU(color);
    //output = color;

    return output;
}

#endif //__TONE_MAPPING_INCLUDED__