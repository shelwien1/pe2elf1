#ifndef __BRDF_INCLUDED__
#define __BRDF_INCLUDED__

#include "baseCG.hlsl"
#include "light.hlsl"
#include "shaderVariables.hlsl"
//#include "standardInput.hlsl"

#define BRDF BRDF1
//#define BRDF BRDF2


inline float3 FresnelSchlick(float3 F0, float cosA)
{
    return F0 + (1 - F0) * pow(1 - saturate(cosA), 5.0);
}
inline float3 FresnelLerp(float3 F0, float3 F90, float cosA)
{
    float t = pow(1 - saturate(cosA), 5); // ala Schlick interpoliation
    return lerp(F0, F90, t);
}

inline float3 fresnelSchlickRoughness(float3 F0, float cosTheta,  float roughness)
{
    return F0 + (max(float3(1.0 - roughness.xxx), F0) - F0) * pow((1.0 - cosTheta), 5.0);
}   

inline float SmithJointGGXVisibilityTerm(float NdotL, float NdotV, float roughness)
{
#if 0
    // Original formulation:
    //  lambda_v    = (-1 + sqrt(a2 * (1 - NdotL2) / NdotL2 + 1)) * 0.5f;
    //  lambda_l    = (-1 + sqrt(a2 * (1 - NdotV2) / NdotV2 + 1)) * 0.5f;
    //  G           = 1 / (1 + lambda_v + lambda_l);

    // Reorder code to be more optimal
    float a          = roughness;
    float a2         = a * a;

    float lambdaV    = NdotL * sqrt((-NdotV * a2 + NdotV) * NdotV + a2);
    float lambdaL    = NdotV * sqrt((-NdotL * a2 + NdotL) * NdotL + a2);

    // Simplify visibility term: (2.0f * NdotL * NdotV) /  ((4.0f * NdotL * NdotV) * (lambda_v + lambda_l + 1e-5f));
    return 0.5f / (lambdaV + lambdaL + 1e-5f);  // This function is not intended to be running on Mobile,
                                                // therefore epsilon is smaller than can be represented by half
#else
    // Approximation of the above formulation (simplify the sqrt, not mathematically correct but close enough)
    float a = roughness;
    float lambdaV = NdotV * (NdotV * (1 - a) + a);
    float lambdaL = NdotL * (NdotL * (1 - a) + a);

    return 0.5f / (lambdaV + lambdaL + 1e-5f);
#endif
}

float GGX_PartialGeometry(float cosThetaN, float alpha) {
    float cosTheta_sqr = saturate(cosThetaN*cosThetaN);
    float tan2 = ( 1 - cosTheta_sqr ) / cosTheta_sqr;
    float GP = 2 / ( 1 + sqrt( 1 + alpha * alpha * tan2 ) );
    return GP;
}

float GGX_Distribution(float cosThetaNH, float alpha) {
    float alpha2 = alpha * alpha;
    float NH_sqr = saturate(cosThetaNH * cosThetaNH);
    float den = NH_sqr * alpha2 + (1.0 - NH_sqr);
    return alpha2 / ( PI * den * den );
}

// Single term for separable Schlick-GGX below.
float gaSchlickG1(float NdotV, float k)
{
    return NdotV / (NdotV * (1.0 - k) + k);
}

// Schlick-GGX approximation of geometric attenuation function using Smith's method.
float gaSchlickGGX(float NdotL, float NdotV, float roughness)
{
    float r = roughness + 1.0;
    float k = (r * r) / 8.0; // Epic suggests using this roughness remapping for analytic lights.
    return gaSchlickG1(NdotL, k) * gaSchlickG1(NdotV, k);
}

float G_smith_ggx(in float NoL, in float NoV, in float a)
{
    float a2 = a*a;
    float G_V = NoV + sqrt((NoV - NoV * a2) * NoV + a2);
    float G_L = NoL + sqrt((NoL - NoL * a2) * NoL + a2);
    return rcp(G_V * G_L);
}

inline float GGXTerm(float NdotH, float roughness)
{
    float a2 = roughness * roughness;
    float d = (NdotH * a2 - NdotH) * NdotH + 1.0f; 
    return INV_PI * a2 / (d * d + 1e-7f); 
}

// Note: Disney diffuse must be multiply by diffuseAlbedo / PI. This is done outside of this function.
float DisneyDiffuse(float NdotV, float NdotL, float LdotH, float perceptualRoughness)
{
    float fd90 = 0.5 + 2 * LdotH * LdotH * perceptualRoughness;
    // Two schlick fresnel term
    float lightScatter = (1 + (fd90 - 1) * pow(1 - NdotL, 5));
    float viewScatter = (1 + (fd90 - 1) * pow(1 - NdotV, 5));

    return lightScatter * viewScatter;
}

// Returns number of mipmap levels for specular IBL environment map.
uint querySpecularTextureLevels()
{
    uint width, height, levels;
    specularTexture0.GetDimensions(0, width, height, levels);
    return levels;
}

//= BRDF - DIFFUSE ==========================================================
// [Gotanda 2012, "Beyond a Simple Physically Based Blinn-Phong Model in Real-Time"]
float3 Diffuse_OrenNayar(float3 DiffuseColor, float Roughness, float NoV, float NoL, float VoH)
{
    float a = Roughness * Roughness;
    float s = a; // / ( 1.29 + 0.5 * a );
    float s2 = s * s;
    float VoL = 2 * VoH * VoH - 1; // double angle identity
    float Cosri = VoL - NoV * NoL;
    float C1 = 1 - 0.5 * s2 / (s2 + 0.33);
    float C2 = 0.45 * s2 / (s2 + 0.09) * Cosri * (Cosri >= 0 ? rcp(max(NoL, NoV + 0.0001f)) : 1);
    return DiffuseColor / PI * (C1 + C2) * (1 + Roughness * 0.5);
}

float4 BRDF1(float3 albedo, float3 specColor, float roughness, float metalness, float3 normal, float3 viewDir, BaseGI gi, float shadow)
{
    float3 halfDir = normalize(float3(gi.light.dir) + viewDir);

#if 1
    // The amount we shift the normal toward the view vector is defined by the dot product.
    float shiftAmount = dot(normal, viewDir);
    normal = shiftAmount < 0.0f ? normal + viewDir * (-shiftAmount + 1e-5f) : normal;
    // A re-normalization should be applied here but as the shift is small we don't do it to save ALU.
    //normal = normalize(normal);

    float nv = saturate(dot(normal, viewDir)); // TODO: this saturate should no be necessary here
#else
    float nv = abs(dot(normal, viewDir)); // This abs allow to limit artifact
#endif    

    float nl = saturate(dot(normal, gi.light.dir));
    float nh = saturate(dot(normal, halfDir));
    float hv = saturate(dot(halfDir, viewDir));

    float lv = saturate(dot(gi.light.dir, viewDir));
    float lh = saturate(dot(gi.light.dir, halfDir));

	// Specular reflection vector.
    float3 Lr = 2.0 * nv * normal - viewDir;
    roughness = max(roughness, 0.08);
    float rough_sqr = roughness * roughness;

    float3 F = FresnelSchlick(specColor, hv);
    float D = GGXTerm(nh, rough_sqr);
    //float D = GGX_Distribution(nh, rough_sqr);
    float G = gaSchlickGGX(nl, nv, roughness);
    //float G = SmithJointGGXVisibilityTerm(nl, nv, rough_sqr);
    //float G = G_smith_ggx(nl, nv, rough_sqr);
    //float G = GGX_PartialGeometry(nv, rough_sqr) * GGX_PartialGeometry(nl, rough_sqr);

    //float3 kd = lerp(1.0f - F, 0.0f, metalness);
    float3 kd = (1.0f - F) * (1.0 - metalness);
    
    //float3 diffuseTerm1 = Diffuse_OrenNayar(albedo, roughness, nv, nl, lh);
    float diffuseTerm1 = DisneyDiffuse(nv, nl, lh, roughness);

    //float3 diffuseBRDF = kd * diffuseTerm1;
    float3 diffuseBRDF = kd * diffuseTerm1 * albedo;
    //float3 diffuseBRDF = albedo / PI * kd;
    //float3 diffuseBRDF = kd * albedo;
    //float3 specularBRDF = D * F * G / max(Epsilon, 4.0 * nl * nv);
    float3 specularBRDF = (D * G) * F / max(Epsilon, 4.0 * nl * nv);
    //float3 specularBRDF = D * F * G * 0.25 / (nv + 0.001);
    //float3 specularBRDF = G*F*hv/(nv*nh);

    float3 color = (diffuseBRDF + specularBRDF) * gi.light.color * nl;

    float3 ambientLighting;
    {
    
        float3 irradiance = irradianceTexture0.Sample(defaultSampler, mul(mul(normal, (float3x3)fixRotationMatrix), (float3x3)ambientRotationMatrix)).rgb;
        //float3 F1 = FresnelSchlick(specColor, nv);
        //float3 F1 = FresnelSchlick(F0, nv);
        float3 F1 = fresnelSchlickRoughness(specColor, nv, roughness);
        //kd = lerp(1.0 - F1, 0.0, metalness);
        kd = 1.0 - F1;
        kd *= (1.0-metalness);
        //float3 diffuseIBL = ShadeSH9(half4(normal, 1)) * 0.2f;
        float3 diffuseIBL = kd * albedo * irradiance;

    
        uint specularTextureLevels = querySpecularTextureLevels();
        float3 specularIrradiance = specularTexture0.SampleLevel(defaultSampler, mul(mul(Lr, (float3x3)fixRotationMatrix), (float3x3)ambientRotationMatrix), roughness * specularTextureLevels).rgb;
        //float3 specularIrradiance = specularTexture.SampleLevel(defaultSampler, Lr, 0).rgb;

		// Split-sum approximation factors for Cook-Torrance specular BRDF.
        float2 specularBRDF1 = specularBRDF_LUT.Sample(specularBRDFSampler, float2(max(nv,0), roughness)).rg;

		// Total specular IBL contribution.
        float3 specularIBL = (F1 * specularBRDF1.x + specularBRDF1.y) * specularIrradiance;
        //float3 specularIBL = (specularBRDF1.x + specularBRDF1.y) * specularIrradiance;

        ambientLighting = (diffuseIBL + specularIBL) * ambientColor.a;
        //return float4(ambientLighting, 1);
    }

    color = (color * shadow + ambientLighting)* gi.occlusion;
    
    
    return float4(color,1);
    
    //return float4(color * shadow + ambientLighting, 1);
    //return float4(ambientLighting, 1);
    //return float4(color, 1);
    //return float4(diffuseBRDF + specularBRDF, 1);
    //return float4(specularBRDF, 1);
    //return half4(specularTexture.SampleLevel(defaultSampler, Lr, 0).rgb, 1);
}
float4 BRDF2(float3 albedo, float3 specColor, float roughness, float metalness, float3 normal, float3 viewDir, BaseGI gi, float shadow)
{
    float oneMinusDielectricSpec = colorSpaceDielectricSpec.a;
    float oneMinusReflectivity =  oneMinusDielectricSpec - metalness * oneMinusDielectricSpec;
    albedo *=  oneMinusReflectivity;

    float3 halfDir = normalize(float3(gi.light.dir) + viewDir);

#if 1
    // The amount we shift the normal toward the view vector is defined by the dot product.
    float shiftAmount = dot(normal, viewDir);
    normal = shiftAmount < 0.0f ? normal + viewDir * (-shiftAmount + 1e-5f) : normal;
    // A re-normalization should be applied here but as the shift is small we don't do it to save ALU.
    //normal = normalize(normal);

    float nv = saturate(dot(normal, viewDir)); // TODO: this saturate should no be necessary here
#else
    float nv = abs(dot(normal, viewDir)); // This abs allow to limit artifact
#endif    

    float nl = saturate(dot(normal, gi.light.dir));
    float nh = saturate(dot(normal, halfDir));

    float lv = saturate(dot(gi.light.dir, viewDir));
    float lh = saturate(dot(gi.light.dir, halfDir));

	// Specular reflection vector.
    float3 Lr = 2.0 * nv * normal - viewDir;
    float rough_sqr = roughness * roughness;
    rough_sqr = max(rough_sqr, 0.002);

    float3 F = FresnelSchlick(specColor, lh);
    float D = GGXTerm(nh, rough_sqr);
    float G = gaSchlickGGX(nl, nv, rough_sqr);

    //float3 kd = lerp(1.0f - F, 0.0f, metalness);
    float3 kd = (1.0f - F) * (1.0 - metalness);
    float diffuseTerm = DisneyDiffuse(nv, nl, lh, roughness) * nl;

    float specularTerm = G*D * PI;
    specularTerm = max(0, specularTerm * nl);
    float surfaceReduction;
    surfaceReduction = 1.0 / (rough_sqr*rough_sqr + 1.0);           // fade \in [0.5;1]

    
    float3 ambientLighting;
    
        float3 irradiance = irradianceTexture0.Sample(defaultSampler, mul(mul(normal, (float3x3)fixRotationMatrix), (float3x3)ambientRotationMatrix)).rgb;
        float3 F1 = fresnelSchlickRoughness(specColor, nv, roughness);
        kd = 1.0 - F1;
        kd *= (1.0-metalness);
        float3 diffuseIBL = irradiance * ambientColor.a;

    
        uint specularTextureLevels = querySpecularTextureLevels();
        float3 specularIrradiance = specularTexture0.SampleLevel(defaultSampler, mul(mul(Lr, (float3x3)fixRotationMatrix), (float3x3)ambientRotationMatrix), roughness * specularTextureLevels).rgb;
        //float3 specularIrradiance = specularTexture.SampleLevel(defaultSampler, Lr, 0).rgb;

		// Split-sum approximation factors for Cook-Torrance specular BRDF.
        float2 specularBRDF1 = specularBRDF_LUT.Sample(specularBRDFSampler, float2(max(nv,0), roughness)).rg;
        float3 specularIBL = (F1 * specularBRDF1.x + specularBRDF1.y) * specularIrradiance * ambientColor.a;

    specularTerm *= any(specColor) ? 1.0 : 0.0;

    float grazingTerm = saturate((1-roughness) + (1-oneMinusReflectivity));
    float3 lightColor = gi.light.color * shadow;
    return float4(specularTerm * lightColor,1);
    float3 color = albedo * (diffuseIBL + lightColor * diffuseTerm)
                    + specularTerm * lightColor * FresnelSchlick(specColor, lh)
                    + surfaceReduction * specularIBL * FresnelLerp (specColor, grazingTerm, nv);

    return float4(color,1);
}



#endif // __BRDF_INCLUDED__