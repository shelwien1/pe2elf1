#ifndef __LIGHT_INCLUDED__
#define __LIGHT_INCLUDED__

#include "baseCG.hlsl"

TextureCube<float4> specularTexture0 : register(t5);
TextureCube<float4> irradianceTexture0 : register(t6);
TextureCube<float4> specularTexture1 : register(t7);
TextureCube<float4> irradianceTexture1 : register(t8);
Texture2D<float4> specularBRDF_LUT : register(t9);

SamplerState specularBRDFSampler : register(s9);

struct Light
{
    float3 color;
    float3 dir;
};

struct Indirect
{
    float3 diffuse;
    float3 specular;
};

struct BaseGI
{
    Light light;
    Indirect indirect;
    float occlusion;
};

void applyHorizontalFog(in float4 pos, inout float3 pixel)
{
    pixel = lerp(pixel, fogColor.rgb, saturate((pos.x - fogMax.x) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((fogMin.x - pos.x) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((pos.y - fogMax.y) / fogBorder));
    pixel = lerp(pixel, fogColor.rgb, saturate((fogMin.y - pos.y) / fogBorder));
}

void applyVerticalFog(in float4 pos, inout float3 pixel)
{
    pixel = lerp(pixel, fogTopVerticalColor.rgb, clamp(saturate((pos.z - topFog) / topFogBorder), 0.0, saturate(topOpacity)));
    pixel = lerp(pixel, fogBottomVerticalColor.rgb, clamp(saturate((bottomFog - pos.z) / bottomFogBorder), 0.0, saturate(bottomOpacity)));
}



#endif // __LIGHT_INCLUDED__