#ifndef __BASE_CG_INCLIDED__
#define __BASE_CG_INCLIDED__

#include "shaderVariables.hlsl"

static const float PI = 3.1415926535897932384626433832795;
static const float INV_PI = 0.31830988618f;
// Constant normal incidence Fresnel factor for all dielectrics.
static const float3 Fdielectric = 0.04;
static const float Epsilon = 0.00001;
#define colorSpaceDielectricSpec float4(0.04, 0.04, 0.04, 1.0 - 0.04) // standard dielectric reflectivity coef at incident angle (= 4%)

SamplerState defaultSampler : register(s0);

struct appdata_base
{
    float3 position : POSITION;
    float3 normal : NORMAL;
    float4 tangent : TANGENT;
    float2 uv : TEXCOORD0;
    float2 uv1 : TEXCOORD1;
    float4 blendIndices: BLENDINDICES;
    float4 blendWeighs: BLENDWEIGHT;
#ifdef _USE_VERTEX_COLOR
    float4 colors : COLOR;
#endif
};

struct appdata_full {
    float4 vertex : POSITION;
    float4 tangent : TANGENT;
    float3 normal : NORMAL;
    float4 texcoord : TEXCOORD0;
    float4 texcoord1 : TEXCOORD1;
    float4 texcoord2 : TEXCOORD2;
    float4 texcoord3 : TEXCOORD3;
    float4 color : COLOR;
};


inline float3 cameraDirection()
{
    return float3(matrixView[0][2], matrixView[1][2], matrixView[2][2]);
}

// Tranforms position from world to homogenous space 
inline float4 WorldToClipPos(in float3 pos)
{
    return mul(matrixViewProj, float4(pos, 1.0));
}

// Tranforms position from view to homogenous space
inline float4 ViewToClipPos(in float3 pos)
{
    return mul(matrixProj, float4(pos, 1.0));
}

// Tranforms position from object to camera space
inline float3 ObjectToViewPos(in float3 pos)
{
    return mul(matrixView, mul(matrix_ObjectToWorld, float4(pos, 1.0))).xyz;
}
inline float3 ObjectToViewPos(float4 pos) // overload for float4; avoids "implicit truncation" warning for existing shaders
{
    return ObjectToViewPos(pos.xyz);
}

// Tranforms position from world to camera space
inline float3 WorldToViewPos(in float3 pos) 
{
    return mul(matrixView, float4(pos, 1.0)).xyz;
}

// Transforms direction from object to world space
inline float3 ObjectToWorldDir(in float3 dir)
{
    return normalize(mul(dir, (float3x3) matrix_ObjectToWorld));
}

// Transforms normal from object to world space
inline float3 ObjectToWorldNormal(in float3 norm)
{
    return ObjectToWorldDir(norm);
}

// Tranforms position from object to homogenous space
inline float4 ObjectToClipPos(in float3 pos)
{
    return mul(mul(float4(pos, 1.0), matrix_ObjectToWorld), matrixViewProj);
}

inline float4 ObjectToClipPos(float4 pos) // overload for float4; avoids "implicit truncation" warning for existing shaders
{
    return ObjectToClipPos(pos.xyz);
}

// Computes world space view direction, from world space position
inline float3 WorldSpaceViewDir(in float3 worldPos)
{
    return normalize(worldSpaceCameraPos - worldPos);
}

inline float3 unpackNormal(float2 packedNormal)
{
    float3 normal;
    normal.xy = packedNormal * 2 - 1;
    normal.z = sqrt(1 - saturate(dot(normal.xy, normal.xy)));
    return normal;
}

inline uint4 unpackBlendIndices(in uint packedIndices)
{
	uint4 output = (uint4)0;
    output.x = ( packedIndices & 0x000000FF);
	output.y = ( packedIndices & 0x0000FF00) >> 8;
	output.z = ( packedIndices & 0x00FF0000) >> 16;
	output.w = ( packedIndices & 0xFF000000) >> 24;
	return output;
}

float3x3 makeTBN(float3 n, float4 t)
{
	// re-orthogonalize T with respect to N
    t.xyz = normalize(t.xyz - dot(t.xyz, n) * n);
	// compute bitangent
    float3 b = cross(n, t.xyz) * t.w;
	// create matrix
    return float3x3(t.xyz, b, n);
}

/*
// normal should be normalized, w=1.0
float3 SHEvalLinearL0L1(float4 normal)
{
    float3 x;

    // Linear (L1) + constant (L0) polynomial terms
    x.r = dot(shAr, normal);
    x.g = dot(shAg, normal);
    x.b = dot(shAb, normal);

    return x;
}

// normal should be normalized, w=1.0
float3 SHEvalLinearL2(float4 normal)
{
    float3 x1, x2;
    // 4 of the quadratic (L2) polynomials
    float4 vB = normal.xyzz * normal.yzzx;
    x1.r = dot(shBr, vB);
    x1.g = dot(shBg, vB);
    x1.b = dot(shBb, vB);

    // Final (5th) quadratic (L2) polynomial
    float vC = normal.x * normal.x - normal.y * normal.y;
    x2 = shC.rgb * vC;

    return x1 + x2;
}

// normal should be normalized, w=1.0
// output in active color space
float3 ShadeSH9(float4 normal)
{
    // Linear + constant polynomial terms
    float3 res = SHEvalLinearL0L1(normal);

    // Quadratic polynomials
    res += SHEvalLinearL2(normal);

#ifdef COLORSPACE_GAMMA
        res = LinearToGammaSpace (res);
#endif

    return res;
}
*/

#endif // __BASE_CG_INCLIDED__