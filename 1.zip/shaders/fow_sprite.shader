#include "common/baseCG.hlsl"
#include "common/shaderVariables.hlsl"


Texture2D<float4> _mainTexture : register(t0);

struct SpriteData
{
    float3 pos;
    float2 dir;
    float4 color;
    float size;
    float intensity;
    float1 padding;
};

StructuredBuffer<SpriteData> spriteData : register(t1);

struct v2v
{
    float4 position : POSITION;
    float2 uv : TEXCOORD0;
};

struct v2p
{
    float4 pixelPosition : SV_POSITION;
    float2 uv : TEXCOORD0;
    float4 color: COLOR;
    float intensity: TEXCOORD1;
};

v2p mainVS(v2v v, uint id : SV_InstanceID)
{
    float size = spriteData[id].size;
    float2 pos = spriteData[id].pos;
    float2 dir = spriteData[id].dir;
    float4 color = spriteData[id].color;
    float intensity = spriteData[id].intensity;
    
    INITIALIZE_OUTPUT(v2p, o);
    o.uv = float2(1,1) - v.uv.yx;
    o.intensity = intensity;
    o.color = color;

    float2 position = {dir.x * v.position.x - dir.y * v.position.y,  dir.y * v.position.x + dir.x * v.position.y};
    position = position * size + pos;
    o.pixelPosition = mul(float4(position,0, 1), matrixViewProj);
    
    return o;
}

float4 mainPS(v2p p) : SV_TARGET
{
    return float4(0,0,0,_mainTexture.Sample(defaultSampler, p.uv).r);
}

float4 lightPS(v2p p) : SV_TARGET
{
    //return float4(1,0,0,_mainTexture.Sample(defaultSampler, p.uv).r);
    float4 color = _mainTexture.Sample(defaultSampler, p.uv); 
    color.rgb = saturate(color.rgb * p.color.rgb * p.intensity);
    return color;
}


