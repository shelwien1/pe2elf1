-------------------------------------------------------------------------
-- o_O
-- не изменяйте этот файл если вам нужно всего лишь изменить стартовую миссию в локальной версии
-- создайте для это файл userexec.lua (там же) и пропишите там нужное значени переменной spawn_name
-- например: spawn_name = 'region1'; --указывать надо только название, без пути и расширения
-- это произведет оверрайд переменой заданной тут
-- файл userexec.lua не надо коммитить
-- файл autoexec.bat нужно менять только если надо изменить что-то глобально для игры, а не для локальной версии
-- в файле userexec.lua можно также менять все консольные переменные для локальной версии.
-------------------------------------------------------------------------
spawn_path = "spawns/"
spawn_ext = ".sws"

dofile("scripts/global_map.lua")
dofile("scripts/triggers.lua")
dofile("network.lua")
dofile("skirmish.lua")

local cmdLine = console.getCommandLine()

if (string.find(cmdLine, "%-%-mipdetails") ~= nil) then
	console.setvar("render.debug.mipdetails", true)
end

-----------------------------------------------------------

--console.setvar("render.shadowMapTechnique", "PSM")
console.setvar("render.mipMapLodBias", -1.0)
--console.setvar("render.landShadows", false)
--console.setvar("render.mode.windowed", false)
--console.setvar("game.freeCamera", true)
console.setvar("render.softShadows", true)
--console.setvar("render.enableDebugText", false)
--console.setvar("game.constantFrameTime", 100)
--console.setvar("render.meshTips", 0)
console.setvar("game.maxLogicFrameTime", 120)
console.setvar("render.deleteColorMask", true)
console.setvar("render.castSilhouettes", false)

console.setvar("game.usLobbyServer", "52.206.112.150:15432")
console.setvar("game.usGameServer", "52.206.112.150:15433")

console.setvar("game.euLobbyServer", "18.168.117.251:15432")
console.setvar("game.euGameServer", "18.168.117.251:15433")

console.setvar("game.krLobbyServer", "3.34.87.220:15432")
console.setvar("game.krGameServer", "3.34.87.220:15433")

console.setvar("game.defaultLocalization", "en")

-----------------------------------------------------------

console.waitFrames(32);

-----------------------------------------------------------

spawns = {}

spawns[1] = "buildtest"

spawn_name = "test"
global_map = "global_map"
minZoom = 200
maxZoom = 400

local autostart = true
local first_mission = "1st_mission"

console.setvar("game.autostart", autostart)
console.setvar("game.firstMission", first_mission)

-----------
-- после этой строчки консольные переменные лучше не менять - иначе их оверрайд не будет работать
-------------------------------------------------------------

local userdata = loadfile("userexec.lua")

if ((userdata ~= nil) and (type(userdata) == "function")) then
	userdata()
end

if (lobbyServer ~= nil) then
	console.setvar("game.lobbyServer", lobbyServer)
end

if (gameServer ~= nil) then
	console.setvar("game.gameServer", gameServer)
end

-------------------------------------------------------------
if (string.find(cmdLine, "%-%-noreport") ~= nil) then
	console.enableReport(false)
end

if (string.find(cmdLine, "%-%-cheats_resources") ~= nil) then
	console.setvar("cheats.allowAddResources", true)
end

if (string.find(cmdLine, "%-%-cheats_godmode") ~= nil) then
	console.setvar("cheats.godMode", true)
end

if (network_user ~= nil) then
	game.networkLogin(network_user, network_pass, network_serial)
end

if (string.find(cmdLine, "%-%-loadtm") ~= nil) then
	--game.enterMainMenu()
	--game.enterGlobalMap(global_map)
	
	--addMissionReserve(missionName)
	game.enterTacticalMap("player", "", spawn_path..spawn_name..spawn_ext)
	--game.enableFogOfWarRendering(false)
	--game.setCameraProperties(minZoom, maxZoom)
elseif (string.find(cmdLine, "%-%-loadgm") ~= nil) then
	game.enterGlobalMap(global_map)
elseif (string.find(cmdLine, "%-%-skirmish") ~= nil) then
	game.startSkirmish(spawn_path..skirmish_spawn..spawn_ext, player_name, 1, preset, "normal")
else
	--game.enterMainMenu()
	--game.enterLogoVideo()
	game.enterSelectLanguage()
end

-------------------------------------------------------------

--game.enableFogOfWarRendering(true)
--console.setvar("sound.enabled", false)

-------------------------------------------------------------
